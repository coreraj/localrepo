const LTV={products:[],cities:[["khurja","Khurja","Blue Pottery","The Ceramic City","https://images.unsplash.com/photo-1630042924261-7453b1957f5c?w=800&h=500&fit=crop"],["jaipur","Jaipur","Block Printing & Blue Pottery","The Pink City of Crafts","https://images.unsplash.com/photo-1607160913542-6234aae47ec5?w=800&h=500&fit=crop"],["varanasi","Varanasi","Silk Weaving","The City of Weavers","https://images.unsplash.com/photo-1561028341-d1fbd27889b2?w=800&h=500&fit=crop"],["moradabad","Moradabad","Brassware","Brass City of India","https://images.unsplash.com/photo-1552590854-5b55d5425066?w=800&h=500&fit=crop"],["srinagar","Srinagar","Wood Carving & Pashmina","Paradise of Craftsmanship","https://images.unsplash.com/photo-1511729530272-7198cdce7b8a?w=800&h=500&fit=crop"],["bidar","Bidar","Bidri Work","City of Silver & Shadow","https://images.pexels.com/photos/19035171/pexels-photo-19035171.jpeg?w=800&h=500&fit=crop"]]};
const store={
  get(k){
    try{return JSON.parse(localStorage.getItem("ltv_"+k)||"[]")}catch(e){return[]}
  },
  set(k,v){
    localStorage.setItem("ltv_"+k,JSON.stringify(v));
    this.refresh();
  },
  add(k,item){
    const nextItem={...item,id:String(item.id??item.title??"")};
    const a=this.get(k);
    const i=a.findIndex(x=>String(x.id)===nextItem.id);
    if(i>-1){
      a[i].qty=(a[i].qty||1)+1;
    } else {
      a.push({...nextItem,qty:1});
    }
    this.set(k,a);
  },
  remove(k,id){
    const targetId=String(id);
    this.set(k,this.get(k).filter(x=>String(x.id)!==targetId));
  },
  refresh(){
    this.refreshWishlist();
    this.refreshGift();
    syncPdpBundleState();
  },
  refreshWishlist(){
    document.querySelectorAll("[data-wishlist-count]").forEach(e=>{const n=this.get("wishlist").length;e.textContent=n?n:""});
    syncWishlistState();
    updateStickyBar();
  },
  refreshGift(){
    const items=this.get("gift").filter(item=>item.id!=="custom-gift");
    const count=items.reduce((sum,item)=>sum+Math.max(1,Number(item.qty||1)),0);
    const total=items.reduce((sum,item)=>{
      const price=Number(String(item.price||0).replace(/[^0-9.]/g,""))||0;
      return sum+(price*Math.max(1,Number(item.qty||1)));
    },0);
    document.querySelectorAll("[data-gift-count]").forEach(e=>{e.textContent=count?count:""});
    document.querySelectorAll("[data-gift-bundle-bar]").forEach(bar=>{
      bar.hidden=count===0;
      bar.classList.toggle("is-visible",count>0);
    });
    document.querySelectorAll("[data-gift-bundle-count]").forEach(e=>{e.textContent=count});
    document.querySelectorAll("[data-gift-bundle-total]").forEach(e=>{e.textContent="Rs. "+total.toLocaleString("en-IN",{maximumFractionDigits:0})});
    updateStickyBar();
  }
};

function syncWishlistState(){
  const ids=new Set(store.get("wishlist").flatMap(item=>[item.id,item.variantId].filter(Boolean).map(String)));
  document.querySelectorAll("[data-wishlist-add]").forEach(button=>{
    const card=button.closest("[data-product-card]");
    const keys=[card?.dataset.id,card?.dataset.variantId,card?.dataset.productId].filter(Boolean).map(String);
    const saved=keys.some(key=>ids.has(key));
    const icon=button.querySelector("iconify-icon");
    button.classList.toggle("is-wishlisted",saved);
    button.setAttribute("aria-pressed",String(saved));
    button.setAttribute("aria-label",saved?"Added to wishlist":"Add to wishlist");
    if(icon){
      if(!button.dataset.wishlistIcon)button.dataset.wishlistIcon=icon.getAttribute("icon")||"lucide:heart";
      icon.setAttribute("icon",saved?(button.dataset.wishlistIconFilled||"mdi:heart"):button.dataset.wishlistIcon);
    }
  });
}

function productCard(p){const variantId=p.variantId||"";const url=p.url||`/products/${p.id}`;const canAdd=/^\d+$/.test(String(variantId));const idSeed=String(p.id||p.title||"").split("").reduce((sum,char)=>sum+char.charCodeAt(0),0);const rating=Number(p.rating||((45+(idSeed%5))/10));const ratingCount=Number(p.ratingCount||0);const ratingMarkup=`<div class="ltv-card-rating" data-rating-widget data-product-id="${p.id}" aria-label="Rated ${rating} out of 5"><span class="ltv-card-rating__stars" aria-hidden="true" style="--rating-percent:${Math.min(100,Math.max(0,rating*20))}%"><span>★★★★★</span></span><small>${rating.toFixed(1)}${ratingCount?` (${ratingCount})`:''}</small></div>`;const hoverActions=`<div class="ltv-product-card__hover-actions">${canAdd?`<button type="button" class="ltv-product-card__hover-btn ltv-product-card__hover-btn--cart" data-local-cart-add data-variant-id="${variantId}" aria-label="Add ${esc(p.title)} to cart" title="Add to cart"><iconify-icon icon="lucide:shopping-bag"></iconify-icon></button>`:''}<button type="button" class="ltv-product-card__hover-btn ltv-product-card__hover-btn--bundle" data-gift-add aria-label="Add ${esc(p.title)} to gift builder" title="Make a bundle"><iconify-icon icon="lucide:package"></iconify-icon></button><button type="button" class="ltv-product-card__hover-btn ltv-product-card__hover-btn--wishlist" data-wishlist-add aria-label="Add ${esc(p.title)} to wishlist" title="Add to wishlist"><iconify-icon icon="lucide:heart"></iconify-icon></button></div>`;return `<article class="ltv-product-card" data-product-card data-product-id="${p.id}" data-id="${p.id}" data-title="${p.title}" data-price="${p.price}" data-image="${p.image}" data-url="${url}" ${canAdd?`data-variant-id="${variantId}"`:''} data-artisan="${p.artisan||''}" data-city="${p.city||''}" data-rating="${rating}" data-rating-count="${ratingCount||''}" data-story="${p.description||''}"><a class="ltv-product-card__image" href="${url}"><img src="${p.image}" width="700" height="875" alt="${p.title}" loading="lazy" decoding="async">${p.bundle?`<span class="ltv-badge" role="button" tabindex="0" data-gift-add aria-label="Add ${p.title} to gift builder"><iconify-icon icon="lucide:package"></iconify-icon>Bundle Ready</span>`:''}<div class="ltv-card-actions"><button type="button" class="ltv-circle-btn" data-wishlist-add aria-label="Add to wishlist"><iconify-icon icon="lucide:heart"></iconify-icon></button>${canAdd?`<button type="button" class="ltv-circle-btn ltv-circle-btn--terra" data-local-cart-add data-variant-id="${variantId}" aria-label="Add to cart"><iconify-icon icon="lucide:shopping-bag"></iconify-icon></button>`:''}</div>${hoverActions}</a><div class="ltv-product-card__body"><div class="ltv-product-card__row"><h3><a href="${url}">${p.title}</a></h3><strong><span>Rs.</span> ${p.price}</strong></div><div class="ltv-product-card__meta"><p><span class="ltv-card-artisan">${p.artisan||'Local Te Vocal'}</span> <span class="ltv-card-divider"></span> <span class="ltv-card-city">${p.city||'India'}</span></p>${ratingMarkup}</div>${p.description?`<blockquote>${p.description}</blockquote>`:''}${canAdd?`<button type="button" class="ltv-product-card__add" data-local-cart-add data-variant-id="${variantId}">Add</button>`:''}</div></article>`}

function catalogProductsFromDom(){
  return [...document.querySelectorAll("[data-product-card]")].map(card=>({
    id:card.dataset.id||card.dataset.variantId||"",
    title:card.dataset.title||card.querySelector("h3")?.textContent?.trim()||"",
    price:card.dataset.price||"",
    image:card.dataset.image||card.querySelector("img")?.getAttribute("src")||"",
    url:card.dataset.url||card.querySelector("a")?.getAttribute("href")||"",
    variantId:card.dataset.variantId||"",
    artisan:card.dataset.artisan||"",
    city:card.dataset.city||"",
    craft:card.dataset.craft||"",
    description:card.dataset.story||"",
    bundle:card.dataset.bundleReady!=="false",
    rating:card.dataset.rating||"",
    ratingCount:card.dataset.ratingCount||""
  })).filter(product=>product.title&&product.image)
}

async function refreshCartCount(){
  try{
    const response=await fetch('/cart.js');
    if(!response.ok)return;
    const cart=await response.json();
    window.LTV_CART_COUNT=cart.item_count||0;
    window.LTV_CART_TOTAL=cart.total_price?cart.total_price/100:0;
    window.LTV_CART_ITEMS=(cart.items||[]).map(item=>({
      variantId:String(item.variant_id||item.id||""),
      title:item.product_title||item.title||"",
      image:item.image||"",
      url:item.url||"/cart",
      quantity:item.quantity||1
    }));
    window.LTV_CART_VARIANT_IDS=(cart.items||[]).map(item=>String(item.variant_id||item.id||""));
    document.querySelectorAll('[data-cart-count]').forEach(e=>{e.textContent=cart.item_count?cart.item_count:''});
    updateStickyBar();
  }catch(e){console.warn('Unable to refresh cart count',e)}
}

async function addToCartAjax(variantId,quantity=1){
  if(!variantId)return false;
  try{
    const response=await fetch('/cart/add.js',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:variantId,quantity})});
    if(response.ok){
      window.LTV_CART_COUNT=Number(window.LTV_CART_COUNT||0)+Number(quantity||1);
      document.querySelectorAll('[data-cart-count]').forEach(e=>{e.textContent=window.LTV_CART_COUNT?window.LTV_CART_COUNT:''});
      updateStickyBar();
      refreshCartCount();
      syncPdpBundleState();
      return true;
    }
  }catch(e){console.warn('Add to cart failed',e)}
  return false;
}

async function addItemsToCartAjax(items){
  if(!Array.isArray(items)||!items.length)return false;
  try{
    const response=await fetch('/cart/add.js',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({items})});
    if(response.ok){
      const addedCount=items.reduce((sum,item)=>sum+Number(item.quantity||1),0);
      window.LTV_CART_COUNT=Number(window.LTV_CART_COUNT||0)+addedCount;
      document.querySelectorAll('[data-cart-count]').forEach(e=>{e.textContent=window.LTV_CART_COUNT?window.LTV_CART_COUNT:''});
      updateStickyBar();
      refreshCartCount();
      syncPdpBundleState();
      return true;
    }
    console.warn('Gift cart add failed',await response.text());
  }catch(e){console.warn('Gift cart add failed',e)}
  return false;
}

async function updateCartGiftAttributes(attributes={},note){
  try{
    const body={attributes};
    if(note)body.note=note;
    const response=await fetch('/cart/update.js',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(body)});
    return response.ok;
  }catch(e){
    console.warn('Gift cart attributes failed',e);
    return false;
  }
}

function ltvStickyEscape(value){
  return String(value??"").replace(/[&<>"']/g,match=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[match]));
}

function ltvStickyNumber(value){
  return Number(String(value??0).replace(/[^0-9.]/g,""))||0;
}

function ltvStickyMoney(value){
  return "Rs. "+(Number(value)||0).toLocaleString("en-IN",{maximumFractionDigits:0});
}

function ltvGiftSummary(){
  const items=store.get("gift").filter(item=>item.id!=="custom-gift");
  const count=items.reduce((sum,item)=>sum+Math.max(1,Number(item.qty||1)),0);
  const total=items.reduce((sum,item)=>sum+(ltvStickyNumber(item.price)*Math.max(1,Number(item.qty||1))),0);
  return {items,count,total,images:items.map(item=>item.image).filter(Boolean).slice(0,2)};
}

function syncPdpBundleState(){
  const root=document.querySelector("[data-product-detail]");
  if(!root)return;
  const cartIds=new Set((window.LTV_CART_VARIANT_IDS||[]).map(String));
  const giftItems=store.get("gift").filter(item=>item.id!=="custom-gift");
  const giftIds=new Set(giftItems.flatMap(item=>[item.id,item.variantId]).filter(Boolean).map(String));
  root.querySelectorAll("[data-bundle-related-item]").forEach(item=>{
    const input=item.querySelector("[data-bundle-related-input]");
    if(!input)return;
    const selected=cartIds.has(String(input.dataset.variantId||""))||giftIds.has(String(input.dataset.productId||""))||giftIds.has(String(input.dataset.variantId||""));
    input.checked=selected;
    item.classList.toggle("is-selected",selected);
  });
}

function ltvStickyContext(){
  const body=document.body;
  const path=location.pathname;
  if(document.querySelector("[data-product-detail]"))return "product";
  if(document.querySelector("[data-gift-builder]"))return "gift";
  if(body.classList.contains("template-cart")||path==="/cart"||document.querySelector("[data-local-cart]"))return "utility";
  if(path.includes("/account")||path.includes("/pages/wishlist")||document.querySelector("[data-wishlist-page]")||document.querySelector(".ltv-account-page")||document.querySelector(".ltv-customer-dashboard"))return "utility";
  if(document.querySelector("[data-stories-page]"))return "stories";
  if(document.querySelector(".ltv-cities-page"))return "cities";
  if(document.querySelector("[data-collection-page]"))return "collection";
  if(body.classList.contains("template-index"))return "home";
  return "default";
}

function ltvProductStickyTotal(){
  const bundleTotal=document.querySelector("[data-bundle-total]")?.textContent?.trim();
  if(bundleTotal)return bundleTotal;
  const priceText=document.querySelector(".ltv-pdp-price span")?.textContent?.trim();
  return priceText||"Rs. 0";
}

function ltvGiftTotalForCurrentPage(summary){
  const builderTotal=document.querySelector("[data-gift-total]")?.textContent?.trim();
  if(builderTotal&&summary.count)return builderTotal;
  return ltvStickyMoney(summary.total);
}

function initStickyBarDots(bar){
  const track=bar.querySelector("[data-sticky-slides]");
  const dots=[...bar.querySelectorAll("[data-sticky-dot]")];
  if(!track||!dots.length)return;
  const sync=()=>{
    const index=Math.round(track.scrollLeft/Math.max(1,track.clientWidth));
    dots.forEach((dot,i)=>dot.classList.toggle("is-active",i===index));
  };
  dots.forEach((dot,index)=>dot.addEventListener("click",()=>{
    track.scrollTo({left:index*track.clientWidth,behavior:"smooth"});
  }));
  track.addEventListener("scroll",()=>requestAnimationFrame(sync),{passive:true});
  sync();
}

function updateStickyBar(){
  const bar=document.querySelector("[data-ltv-sticky-bar]");
  if(!bar)return;
  const context=ltvStickyContext();
  {
    if(bar.dataset.showMobileTabbar==="false"){
      bar.hidden=true;
      return;
    }
    const path=location.pathname;
    const d=bar.dataset;
    const cartCount=Number(window.LTV_CART_COUNT||0);
    const cartTotal=Number(window.LTV_CART_TOTAL||0);
    const cartItems=window.LTV_CART_ITEMS||[];
    const gift=ltvGiftSummary();
    const cartBadge=cartCount?`<i>${cartCount}</i>`:"";
    const navItem=(href,icon,label,active,badge="")=>`<a href="${ltvStickyEscape(href)}" class="${active?"is-active":""}"><iconify-icon icon="${ltvStickyEscape(icon)}"></iconify-icon>${badge}<span>${ltvStickyEscape(label)}</span></a>`;
    const thumbs=items=>items.slice(0,2).map(item=>{
      const image=typeof item==="string"?item:item.image;
      return image?`<img src="${ltvStickyEscape(image)}" alt="">`:"";
    }).join("");
    const defaultSlide=`<div class="ltv-sticky-bar__slide ltv-sticky-bar__slide--nav" data-sticky-slide>${[
      navItem(d.homeUrl||"/",d.homeIcon||"lucide:home",d.homeLabel||"Home",context==="home"),
      navItem(d.discoverUrl||"/collections/all",d.discoverIcon||"lucide:search",d.discoverLabel||"Discover",context==="collection"||context==="cities"||context==="stories"||path==="/search"),
      navItem(d.cartUrl||"/cart",d.cartIcon||"lucide:shopping-cart",d.cartLabel||"Cart",path==="/cart",cartBadge),
      navItem(d.profileUrl||"/account",d.profileIcon||"lucide:user",d.profileLabel||"Profile",context==="utility"||path.includes("/account"))
    ].join("")}</div>`;
    const slides=[defaultSlide];
    if(cartCount>0){
      slides.push(`<div class="ltv-sticky-bar__slide" data-sticky-slide><a class="ltv-sticky-summary-card" href="${ltvStickyEscape(d.cartUrl||"/cart")}"><span class="ltv-sticky-summary-card__thumbs">${thumbs(cartItems)||`<span class="ltv-sticky-summary-card__icon"><iconify-icon icon="${ltvStickyEscape(d.cartIcon||"lucide:shopping-cart")}"></iconify-icon></span>`}</span><span class="ltv-sticky-summary-card__copy"><strong>${ltvStickyEscape(d.cartSummaryTitle||"Cart Total")}</strong><small>${cartCount} ${cartCount===1?ltvStickyEscape(d.itemSingular||"item"):ltvStickyEscape(d.itemPlural||"items")}</small></span><b>${ltvStickyEscape(d.cartSummaryCta||"View")} &bull; ${ltvStickyEscape(ltvStickyMoney(cartTotal))}</b></a></div>`);
    }
    if(gift.count>0){
      slides.push(`<div class="ltv-sticky-bar__slide" data-sticky-slide><a class="ltv-sticky-summary-card" href="${ltvStickyEscape(d.giftUrl||"/pages/gift-builder")}"><span class="ltv-sticky-summary-card__thumbs">${thumbs(gift.images)||`<span class="ltv-sticky-summary-card__icon"><iconify-icon icon="${ltvStickyEscape(d.giftIcon||"lucide:gift")}"></iconify-icon></span>`}</span><span class="ltv-sticky-summary-card__copy"><strong>${ltvStickyEscape(d.giftSummaryTitle||"Artisan Bundle")}</strong><small>${gift.count} ${gift.count===1?ltvStickyEscape(d.itemSingular||"item"):ltvStickyEscape(d.itemPlural||"items")}</small></span><b>${ltvStickyEscape(d.giftSummaryCta||"Review")} &bull; ${ltvStickyEscape(ltvGiftTotalForCurrentPage(gift))}</b></a></div>`);
    }
    const dots=slides.length>1?`<div class="ltv-sticky-bar__dots" aria-hidden="true">${slides.map((_,index)=>`<button type="button" data-sticky-dot class="${index===0?"is-active":""}" tabindex="-1"></button>`).join("")}</div>`:"";
    bar.className=`ltv-mobile-tabbar ltv-sticky-bar ltv-sticky-bar--carousel${slides.length>1?" has-summary":""}`;
    bar.hidden=false;
    bar.innerHTML=`<div class="ltv-sticky-bar__slides" data-sticky-slides>${slides.join("")}</div>${dots}`;
    initStickyBarDots(bar);
    return;
  }
  const gift=ltvGiftSummary();
  const wishlistCount=store.get("wishlist").length;
  const cartCount=Number(window.LTV_CART_COUNT||0);
  const cartBadge=cartCount?`<i>${cartCount}</i>`:"";
  const wishlistBadge=wishlistCount?`<i></i>`:"";
  const giftTotal=ltvGiftTotalForCurrentPage(gift);
  const path=location.pathname;

  const navItem=(href,icon,label,active,badge="")=>`<a href="${href}" class="${active?"is-active":""}"><iconify-icon icon="${icon}"></iconify-icon>${badge}<span>${label}</span></a>`;
  const utility=()=>[
    navItem("/account","lucide:user","Account",context==="utility"&&path.includes("/account")),
    navItem("/pages/wishlist","lucide:heart","Wishlist",context==="utility"&&path.includes("/pages/wishlist"),wishlistBadge),
    navItem("/cart","lucide:shopping-bag","Cart",context==="utility"&&path==="/cart",cartBadge)
  ].join("");
  const mainNav=()=>[
    navItem("/","lucide:home","Home",context==="home"),
    navItem("/collections/all","lucide:search","Discover",context==="collection"||context==="cities"||context==="stories"),
    navItem("/cart","lucide:shopping-cart","Cart",false,cartBadge),
    navItem("/account","lucide:user","Profile",context==="utility")
  ].join("");
  const reviewButton=(label="Review Bundle",extra="")=>`<a href="/pages/gift-builder" class="ltv-sticky-bar__button">${label}${extra}</a>`;

  bar.className="ltv-mobile-tabbar ltv-sticky-bar";
  bar.hidden=false;

  if(context==="product"){
    bar.classList.add("ltv-sticky-bar--product");
    bar.innerHTML=`<div class="ltv-sticky-bar__total"><small>Total</small><strong>${ltvStickyEscape(ltvProductStickyTotal())}</strong></div><button type="button" class="ltv-sticky-bar__button" data-sticky-action="product-add-bundle"><iconify-icon icon="lucide:package"></iconify-icon>Add Bundle to Cart</button>`;
    return;
  }

  if(context==="gift"&&gift.count){
    bar.classList.add("ltv-sticky-bar--gift-review");
    bar.innerHTML=`<div class="ltv-sticky-bar__stack"><small>Your Artisan Bundle</small><strong>${gift.count} ${gift.count===1?"item":"items"} • ${ltvStickyEscape(giftTotal)}</strong></div>${reviewButton()}`;
    return;
  }

  if(context==="stories"&&gift.count){
    const imageOne=gift.images[0]?`<img src="${ltvStickyEscape(gift.images[0])}" alt="">`:"";
    const imageTwo=gift.images[1]?`<img src="${ltvStickyEscape(gift.images[1])}" alt="">`:"";
    bar.classList.add("ltv-sticky-bar--capsule");
    bar.innerHTML=`<a href="/pages/gift-builder" class="ltv-sticky-bar__capsule"><span class="ltv-sticky-bar__thumbs">${imageOne}${imageTwo}</span><span><strong>Artisan Bundle</strong><small>${gift.count} ${gift.count===1?"item":"items"}</small></span><b>Review • ${ltvStickyEscape(giftTotal)}</b></a>`;
    return;
  }

  if((context==="cities"||context==="collection")&&gift.count){
    bar.classList.add("ltv-sticky-bar--bundle-row");
    bar.innerHTML=`<div class="ltv-sticky-bar__stack"><small>Artisan Bundle (${gift.count})</small><strong>${ltvStickyEscape(giftTotal)}</strong></div>${reviewButton()}`;
    return;
  }

  if(context==="default"&&gift.count){
    bar.classList.add("ltv-sticky-bar--icon-bundle");
    bar.innerHTML=`<a class="ltv-sticky-bar__summary" href="/pages/gift-builder"><span class="ltv-sticky-bar__package"><iconify-icon icon="lucide:package"></iconify-icon><i>${gift.count}</i></span><span><small>Your Bundle</small><strong>${ltvStickyEscape(giftTotal)}</strong></span></a><a href="/pages/gift-builder" class="ltv-sticky-bar__button">Review Bundle <iconify-icon icon="lucide:arrow-right"></iconify-icon></a>`;
    return;
  }

  if(context==="utility"){
    bar.classList.add("ltv-sticky-bar--utility");
    bar.innerHTML=utility();
    return;
  }

  bar.classList.add("ltv-sticky-bar--main");
  bar.innerHTML=mainNav();
}

function bindCommon(){
  store.refreshWishlist();
  store.refreshGift();
  const stickyBar=document.querySelector("[data-ltv-sticky-bar]");
  const serverCartCount=Number(stickyBar?.dataset.cartCount||0);
  const serverCartTotal=Number(stickyBar?.dataset.cartTotal||0);
  window.LTV_CART_COUNT=serverCartCount;
  window.LTV_CART_TOTAL=serverCartTotal;
  updateStickyBar();
  if(serverCartCount>0){
    const refreshCart=()=>refreshCartCount();
    if("requestIdleCallback" in window){
      window.requestIdleCallback(refreshCart,{timeout:2500});
    }else{
      window.setTimeout(refreshCart,1200);
    }
  }
  const closeMega=()=>{
    document.querySelectorAll('[data-mega]').forEach(m=>m.classList.remove('is-open'));
    document.querySelectorAll('[data-mega-trigger]').forEach(trigger=>trigger.setAttribute('aria-expanded','false'));
  };
  const openMega=name=>{
    document.querySelectorAll('[data-mega]').forEach(m=>m.classList.toggle('is-open',m.dataset.mega===name));
    document.querySelectorAll('[data-mega-trigger]').forEach(trigger=>trigger.setAttribute('aria-expanded',String(trigger.dataset.megaTrigger===name)));
  };
  document.addEventListener('mouseover',e=>{
    const trigger=e.target.closest('[data-mega-trigger]');
    if(trigger)openMega(trigger.dataset.megaTrigger);
  });
  document.addEventListener('focusin',e=>{
    const trigger=e.target.closest('[data-mega-trigger]');
    if(trigger)openMega(trigger.dataset.megaTrigger);
  });
  document.addEventListener('click',e=>{
    const trigger=e.target.closest('[data-mega-trigger]');
    if(!trigger)return;
    const menu=document.querySelector(`[data-mega="${trigger.dataset.megaTrigger}"]`);
    if(!menu)return;
    const isCoarse=window.matchMedia('(hover: none), (pointer: coarse)').matches;
    if(isCoarse||!menu.classList.contains('is-open')){
      e.preventDefault();
      menu.classList.contains('is-open')?closeMega():openMega(trigger.dataset.megaTrigger);
    }
  });
  document.addEventListener('mouseout',e=>{
    const header=e.target.closest('[data-ltv-header]');
    if(header&&(!e.relatedTarget||!header.contains(e.relatedTarget)))closeMega();
  });
  document.addEventListener('click',e=>{if(!e.target.closest('[data-ltv-header]'))closeMega()});
  const mobileMenu=document.querySelector('[data-mobile-menu]');
  const mobileOpen=document.querySelector('[data-mobile-open]');
  const setMobileOpen=open=>{
    if(!mobileMenu)return;
    mobileMenu.classList.toggle('is-open',open);
    mobileMenu.setAttribute('aria-hidden',String(!open));
    mobileMenu.toggleAttribute('inert',!open);
    mobileOpen?.setAttribute('aria-expanded',String(open));
    document.body.classList.toggle('ltv-menu-open',open);
  };
  mobileOpen?.addEventListener('click',()=>setMobileOpen(true));
  document.querySelector('[data-mobile-close]')?.addEventListener('click',()=>setMobileOpen(false));
  mobileMenu?.addEventListener('click',e=>{if(e.target.matches('a'))setMobileOpen(false)});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMega();setMobileOpen(false)}});
  if(mobileMenu)setMobileOpen(false);
  document.body.addEventListener('click',async e=>{
    const stickyAction=e.target.closest('[data-sticky-action]');
    if(stickyAction?.dataset.stickyAction==="product-add-bundle"){
      e.preventDefault();
      const bundleButton=document.querySelector(".ltv-pdp-bundle__foot [data-bundle-cart-add]");
      const productButton=document.querySelector(".ltv-pdp-actions [data-local-cart-add]");
      (bundleButton||productButton)?.click();
      return;
    }
    const bundleCartButton=e.target.closest("[data-bundle-cart-add]");
    if(bundleCartButton){
      e.preventDefault();
      const builder=bundleCartButton.closest("[data-bundle-builder]");
      const variantIds=[bundleCartButton.dataset.variantId,...[...(builder?.querySelectorAll("[data-bundle-related-input]:checked")||[])].map(input=>input.dataset.variantId)].filter(id=>/^\d+$/.test(String(id||"")));
      const uniqueIds=[...new Set(variantIds)];
      if(!uniqueIds.length)return;
      bundleCartButton.disabled=true;
      const added=await addItemsToCartAjax(uniqueIds.map(id=>({id:Number(id),quantity:1})));
      bundleCartButton.disabled=false;
      if(added){
        confirmButton(bundleCartButton,"Added selected items");
        notify("Selected items added to cart");
        syncPdpBundleState();
      }
      return;
    }
    const cartButton=e.target.closest('[data-local-cart-add]');
    if(cartButton){
      const form=cartButton.closest('form');
      const variantId=cartButton.dataset.variantId||form?.querySelector('[name="id"]')?.value;
      if(!/^\d+$/.test(String(variantId||''))) return;
      e.preventDefault();
      cartButton.classList.add("is-loading");
      cartButton.disabled=true;
      const added=await addToCartAjax(variantId,Number(cartButton.dataset.quantity||1));
      cartButton.classList.remove("is-loading");
      cartButton.disabled=false;
      if(added){
        confirmButton(cartButton,"Added to cart");
        notify("Added to cart");
      }
      if(!added&&form) form.submit();
      return;
    }
    const wishlistButton=e.target.closest('[data-wishlist-add]');
    if(wishlistButton){
      e.preventDefault();
      const card=wishlistButton.closest('[data-product-card]');
      if(!card)return;
      const saved=wishlistButton.classList.contains("is-wishlisted");
      if(saved){
        const ids=[card.dataset.id,card.dataset.variantId,card.dataset.productId].filter(Boolean).map(String);
        store.set('wishlist',store.get('wishlist').filter(item=>!ids.includes(String(item.id||""))&&!ids.includes(String(item.variantId||""))));
        confirmButton(wishlistButton,"Removed from wishlist");
        notify("Removed from wishlist");
      }else{
        store.add('wishlist',{id:card.dataset.id,title:card.dataset.title,price:card.dataset.price,image:card.dataset.image,url:card.dataset.url,variantId:card.dataset.variantId,artisan:card.dataset.artisan,city:card.dataset.city,story:card.dataset.story});
        confirmButton(wishlistButton,"Added to wishlist");
        notify("Added to wishlist");
      }
      return;
    }
    const giftButton=e.target.closest('[data-gift-add]');
    if(giftButton){
      e.preventDefault();
      const card=giftButton.closest('[data-product-card]');
      const rawPrice=card?.dataset.price||"0";
      const price=Number(String(rawPrice).replace(/[^0-9.]/g,""))||0;
      const item=card?{id:card.dataset.id,title:card.dataset.title,price,image:card.dataset.image,url:card.dataset.url,variantId:card.dataset.variantId,artisan:card.dataset.artisan,city:card.dataset.city,story:card.dataset.story} : {id:'gift-item',title:'Artisan Gift',price:0,image:''};
      store.add('gift',item);
      confirmButton(giftButton,"Added to gift builder");
      notify("Added to gift builder");
      return;
    }
  });
  document.body.addEventListener('keydown',e=>{
    const giftButton=e.target.closest?.('[data-gift-add]');
    if(!giftButton || (e.key!=='Enter'&&e.key!==' ')) return;
    e.preventDefault();
    giftButton.click();
  });
}
function initGrids(){document.querySelectorAll("[data-products-grid]").forEach(el=>{if(!el.innerHTML.trim()){let arr=catalogProductsFromDom();if(el.dataset.limit)arr=arr.slice(0,+el.dataset.limit);el.innerHTML=arr.map(productCard).join("")}});document.querySelectorAll("[data-cities-grid]").forEach(el=>{if(!el.innerHTML.trim()){el.innerHTML=LTV.cities.slice(0,el.dataset.limit||99).map(c=>`<a href="/pages/cities#${c[0]}" class="ltv-city-card"><img src="${c[4]}" width="800" height="500" alt="${c[1]}" loading="lazy" decoding="async"><h3>${c[1]}</h3><p>Famed for: ${c[2]}</p></a>`).join("")}})}
function initProduct(){
  const root=document.querySelector("[data-product-detail]");
  if(!root) return;
  const mainImg=root.querySelector("[data-p-main]");
  const lightbox=root.querySelector("[data-p-lightbox]");
  const lightboxImg=root.querySelector("[data-p-lightbox-img]");
  const thumbsEl=root.querySelector("[data-p-thumbs]");
  if(thumbsEl){
    thumbsEl.addEventListener("click",e=>{
      const b=e.target.closest("button");
      if(!b) return;
      if(mainImg) mainImg.src=b.dataset.thumb;
      if(lightboxImg) lightboxImg.src=b.dataset.thumb;
      thumbsEl.querySelectorAll("button").forEach(x=>x.classList.toggle("is-active",x===b));
    });
  }
  root.querySelector("[data-p-zoom-open]")?.addEventListener("click",()=>{if(lightbox) lightbox.hidden=false});
  root.querySelector("[data-p-zoom-close]")?.addEventListener("click",()=>{if(lightbox) lightbox.hidden=true});
  lightbox?.addEventListener("click",e=>{if(e.target===lightbox) lightbox.hidden=true});
  root.querySelector("[data-ltv-share]")?.addEventListener("click",async event=>{
    const button=event.currentTarget;
    const title=root.dataset.title||document.title;
    const url=location.href;
    if(navigator.share){
      try{
        await navigator.share({title,url});
        confirmButton(button,"Shared");
      }catch(e){}
      return;
    }
    try{
      await navigator.clipboard.writeText(url);
      confirmButton(button,"Link copied");
      notify("Product link copied");
    }catch(e){
      notify("Copy failed. Use your browser address bar to copy the link.");
    }
  });
  root.querySelectorAll("[data-bundle-builder]").forEach(builder=>{
    const totalEl=builder.querySelector("[data-bundle-total]");
    const savingsEl=builder.querySelector("[data-bundle-savings]");
    const base=Number(builder.dataset.basePrice||0);
    function update(){
      let total=base;
      let savings=0;
      builder.querySelectorAll("[data-bundle-item]").forEach(input=>{
        const item=input.closest(".ltv-pdp-bundle__item");
        item?.classList.toggle("is-selected",input.checked);
        if(input.checked) total+=Number(input.dataset.price||0);
        const oldText=item?.querySelector("s")?.textContent?.replace(/[^0-9.]/g,"");
        if(input.checked&&oldText) savings+=Math.max(0,Number(oldText)-Number(input.dataset.price||0));
      });
      if(totalEl) totalEl.textContent="Rs. "+total.toFixed(0);
      if(savingsEl) savingsEl.textContent=savings>0?"You save Rs. "+savings.toFixed(0):"";
      updateStickyBar();
    }
    builder.addEventListener("change",e=>{if(e.target.matches("[data-bundle-item]")) update()});
    update();
    syncPdpBundleState();
  });
}
function initStoriesPage(){
  const root=document;
  if(!document.querySelector("[data-stories-filter], [data-story-item], [data-stories-page]")) return;
  let active="all";
  const bundle=root.querySelector("[data-bundle-filter]");
  function apply(){
    root.querySelectorAll("[data-story-item]").forEach(item=>{
      const category=item.dataset.category;
      const bundleOk=!bundle?.checked||item.dataset.bundle==="true";
      const categoryOk=active==="all"||category===active;
      item.classList.toggle("is-hidden",!(bundleOk&&categoryOk));
    });
  }
  root.querySelectorAll("[data-story-filter]").forEach(button=>{
    button.addEventListener("click",()=>{
      active=button.dataset.storyFilter;
      root.querySelectorAll("[data-story-filter]").forEach(x=>x.classList.toggle("is-active",x===button));
      apply();
    });
  });
  root.querySelectorAll("[data-story-filter-more]").forEach(button=>{
    const filter=button.closest("[data-stories-filter]");
    button.addEventListener("click",()=>{
      const expanded=!filter?.classList.contains("is-expanded");
      filter?.classList.toggle("is-expanded",expanded);
      button.setAttribute("aria-expanded",String(expanded));
    });
  });
  bundle?.addEventListener("change",apply);
  apply();
}
function videoEmbedUrl(url,autoplay=true){
  if(!url)return"";
  const autoplayValue=autoplay?"1":"0";
  try{
    const u=new URL(url,location.origin);
    const host=u.hostname.replace(/^www\./,"");
    if(host==="youtu.be")return`https://www.youtube.com/embed/${u.pathname.slice(1)}?autoplay=${autoplayValue}&rel=0${autoplay?"&mute=1":""}`;
    if(host.includes("youtube.com")){
      const id=u.searchParams.get("v")||u.pathname.split("/").filter(Boolean).pop();
      return id?`https://www.youtube.com/embed/${id}?autoplay=${autoplayValue}&rel=0${autoplay?"&mute=1":""}`:"";
    }
    if(host.includes("vimeo.com")){
      const id=u.pathname.split("/").filter(Boolean).pop();
      return id?`https://player.vimeo.com/video/${id}?autoplay=${autoplayValue}${autoplay?"&muted=1&loop=1":""}`:"";
    }
    return url;
  }catch(e){return url}
}
function youtubeIdFromUrl(url){
  try{
    const u=new URL(url,location.origin);
    const host=u.hostname.replace(/^www\./,"");
    if(host==="youtu.be")return u.pathname.slice(1);
    if(host.includes("youtube.com"))return u.searchParams.get("v")||u.pathname.split("/").filter(Boolean).pop();
  }catch(e){}
  return"";
}
function initVideoPreviews(){
  document.querySelectorAll("[data-video-player]").forEach(player=>{
    const url=player.dataset.videoUrl;
    if(!url||player.querySelector(".ltv-stories-video__poster"))return;
    const direct=/\.(mp4|webm|ogg)(\?.*)?$/i.test(url);
    if(direct){
      const preview=document.createElement("video");
      preview.className="ltv-stories-video__poster ltv-stories-video__poster-video";
      preview.src=url;
      preview.muted=true;
      preview.loop=true;
      preview.autoplay=true;
      preview.playsInline=true;
      preview.preload="metadata";
      preview.setAttribute("aria-hidden","true");
      player.querySelector(".ltv-stories-video__fallback")?.remove();
      player.prepend(preview);
      preview.play?.().catch(()=>{});
      return;
    }
    const id=youtubeIdFromUrl(url);
    if(id){
      const img=document.createElement("img");
      img.className="ltv-stories-video__poster";
      img.src=`https://img.youtube.com/vi/${id}/maxresdefault.jpg`;
      img.onerror=()=>{img.src=`https://img.youtube.com/vi/${id}/hqdefault.jpg`};
      img.alt=player.dataset.videoHeading||"Story video";
      player.querySelector(".ltv-stories-video__fallback")?.remove();
      player.prepend(img);
    }
  });
}
function playInlineVideo(player,trigger,{autoplay=false}={}){
  if(!player||player.classList.contains("is-playing"))return;
  const url=player.dataset.videoUrl;
  if(!url){
    trigger?.blur?.();
    if(!autoplay)notify("Video is not available yet");
    return;
  }
  const embed=videoEmbedUrl(url,true);
  const isFile=/\.(mp4|webm|ogg)(\?.*)?$/i.test(embed);
  const el=document.createElement(isFile?"video":"iframe");
  el.className="ltv-stories-video__embed";
  if(isFile){
    el.src=embed;
    el.controls=!autoplay;
    el.autoplay=true;
    el.loop=autoplay;
    el.muted=autoplay;
    el.playsInline=true;
  }else{
    el.src=embed;
    el.allow="autoplay; encrypted-media; picture-in-picture";
    el.allowFullscreen=true;
    el.title=trigger?.getAttribute("aria-label")||player.dataset.videoHeading||"Story video";
  }
  player.appendChild(el);
  player.classList.add("is-playing");
}
function initInlineVideos(){
  document.querySelectorAll("[data-native-video-autoplay]").forEach(player=>{
    const video=player.querySelector("video");
    if(!video)return;
    const play=()=>video.play?.().catch(()=>{});
    if(!("IntersectionObserver" in window)){
      play();
      return;
    }
    const observer=new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        if(entry.isIntersecting){
          play();
        }else{
          video.pause?.();
        }
      });
    },{rootMargin:"200px 0px",threshold:.01});
    observer.observe(player);
  });
  document.querySelectorAll('[data-video-player][data-video-autoplay="true"]').forEach(player=>{
    playInlineVideo(player,null,{autoplay:true});
  });
  document.body.addEventListener("click",e=>{
    const nativeTrigger=e.target.closest("[data-native-video-play]");
    if(nativeTrigger){
      const player=nativeTrigger.closest(".ltv-maker-video");
      const video=player?.querySelector("video");
      if(video){
        video.play?.();
        player.classList.add("is-playing");
      }
      return;
    }
    const trigger=e.target.closest("[data-video-play]");
    if(!trigger)return;
    const player=trigger.closest("[data-video-player]");
    if(!player){
      notify("Video is not available yet");
      return;
    }
    playInlineVideo(player,trigger);
  });
}
function initHomeStoryAccordion(){
  document.querySelectorAll("[data-home-story-accordion]").forEach(root=>{
    const animateClose=item=>{
      const panel=item?.querySelector(".ltv-story-accordion__panel");
      if(!item||!panel||!item.open)return;
      item.classList.add("is-animating");
      panel.style.height=`${panel.offsetHeight}px`;
      panel.offsetHeight;
      panel.style.height="0px";
      panel.addEventListener("transitionend",()=>{
        item.open=false;
        panel.style.height="";
        item.classList.remove("is-animating");
      },{once:true});
    };

    const animateOpen=item=>{
      const panel=item?.querySelector(".ltv-story-accordion__panel");
      if(!item||!panel||item.open)return;
      root.querySelectorAll(".ltv-story-accordion__item[open]").forEach(openItem=>{
        if(openItem!==item)animateClose(openItem);
      });
      item.open=true;
      item.classList.add("is-animating");
      panel.style.height="0px";
      panel.offsetHeight;
      panel.style.height=`${panel.scrollHeight}px`;
      panel.addEventListener("transitionend",()=>{
        panel.style.height="";
        item.classList.remove("is-animating");
      },{once:true});
    };

    root.addEventListener("click",e=>{
      const summary=e.target.closest(".ltv-story-accordion__item > summary");
      if(!summary||!root.contains(summary))return;
      const item=summary.parentElement;
      if(!item)return;
      e.preventDefault();

      if(item.open){
        animateClose(item);
      }else{
        animateOpen(item);
      }
    });
  });
}
function initCart(){
  const root=document.querySelector("[data-local-cart]");
  if(!root)return;
  root.addEventListener("click",e=>{
    const stepButton=e.target.closest("[data-cart-qty-step]");
    if(!stepButton)return;
    const qty=stepButton.closest(".ltv-cart-qty")?.querySelector('input[name="updates[]"]');
    if(!qty)return;
    const next=Math.max(Number(qty.min||0),Number(qty.value||0)+Number(stepButton.dataset.cartQtyStep||0));
    qty.value=next;
    qty.dispatchEvent(new Event("change",{bubbles:true}));
  });
}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function notify(message){
  let toast=document.querySelector("[data-ltv-toast]");
  if(!toast){
    toast=document.createElement("div");
    toast.className="ltv-toast";
    toast.dataset.ltvToast="";
    toast.setAttribute("role","status");
    toast.setAttribute("aria-live","polite");
    document.body.appendChild(toast);
  }
  toast.textContent=message;
  toast.classList.add("is-visible");
  clearTimeout(notify.timer);
  notify.timer=setTimeout(()=>toast.classList.remove("is-visible"),2600);
}
function confirmButton(button,label="Added"){
  if(!button)return;
  const previousLabel=button.getAttribute("aria-label");
  button.classList.add("is-confirming");
  button.setAttribute("aria-label",label);
  clearTimeout(button._ltvConfirmTimer);
  button._ltvConfirmTimer=setTimeout(()=>{
    button.classList.remove("is-confirming");
    if(previousLabel)button.setAttribute("aria-label",previousLabel);
    else button.removeAttribute("aria-label");
  },900);
}
function moneyText(v){const s=String(v??'').trim();if(!s)return'';return /^(\$|₹|Rs\.|INR|USD|EUR|GBP)/i.test(s)?s:`Rs. ${s}`}
function wishlistCard(item){
  const id=esc(item.id||item.title);
  const title=esc(item.title||'Saved item');
  const url=esc(item.url||'#');
  const image=esc(item.image||'');
  const price=esc(moneyText(item.price));
  const artisan=esc(item.artisan||'');
  const city=esc(item.city||'');
  const story=esc(item.story||'');
  const variant=item.variantId?`data-variant-id="${esc(item.variantId)}"`:'';
  const moveAction=item.variantId?`<button type="button" class="ltv-wish-move" data-wishlist-move="${id}" ${variant}>Move to Cart <iconify-icon icon="lucide:arrow-right"></iconify-icon></button>`:`<a class="ltv-wish-move" href="${url}">View Product <iconify-icon icon="lucide:arrow-right"></iconify-icon></a>`;
  const makerInitial=esc((artisan||title).charAt(0));
  const makerMeta=(artisan||city)?`<div class="ltv-wish-maker"><span class="ltv-wish-maker__avatar">${makerInitial}</span><div>${artisan?`<strong>${artisan}</strong>`:''}${city?`<span><iconify-icon icon="lucide:map-pin"></iconify-icon>${city}</span>`:''}</div></div>`:'';
  const storyText=story?`<blockquote>"${story}"</blockquote>`:'';
  return `<article class="ltv-wish-card" data-wishlist-item data-product-card data-id="${id}" data-title="${title}" data-price="${esc(item.price||'')}" data-image="${image}" data-url="${url}" ${variant}>
    <label class="ltv-wish-check"><input type="checkbox" data-wishlist-select value="${id}"><span></span></label>
    <button type="button" class="ltv-wish-remove" data-wishlist-remove="${id}" aria-label="Remove ${title}"><iconify-icon icon="lucide:trash-2"></iconify-icon></button>
    ${image?`<a href="${url}"><img class="ltv-wish-card__image" src="${image}" width="520" height="650" alt="${title}" loading="lazy" decoding="async"></a>`:''}
    <div class="ltv-wish-card__body">
      ${makerMeta}
      <div class="ltv-wish-title-row"><h2><a href="${url}">${title}</a></h2>${price?`<strong>${price}</strong>`:''}</div>
      ${storyText}
      ${moveAction}
      <button type="button" class="ltv-wish-gift" data-gift-add><iconify-icon icon="lucide:gift"></iconify-icon>Add to Gift Builder</button>
    </div>
  </article>`;
}
function initWishlist(){
  const root=document.querySelector("[data-wishlist-page]");
  if(!root)return;
  if(!root.hasAttribute("data-wishlist-dynamic")){
    const items=store.get("wishlist");
    root.innerHTML=items.length?`<div class="ltv-wishlist-grid">${items.map(wishlistCard).join("")}</div>`:`<div class="ltv-wishlist-empty"><h2>No saved stories yet</h2><p>Save products from the collection and they will appear here.</p><a class="ltv-wishlist-btn ltv-wishlist-btn--terra" href="/collections/all">Explore Collection</a></div>`;
    return;
  }
  const grid=root.querySelector("[data-wishlist-items-grid]");
  const empty=root.querySelector("[data-wishlist-empty]");
  const countEls=document.querySelectorAll("[data-wishlist-item-count]");
  const selectedLabel=document.querySelector("[data-wishlist-selected-label]");
  const getItems=()=>store.get("wishlist");
  function updateSelected(){
    const selected=root.querySelectorAll("[data-wishlist-select]:checked").length;
    if(selectedLabel)selectedLabel.textContent=`${selected} Items Selected`;
  }
  function render(){
    const items=getItems();
    if(grid)grid.innerHTML=items.map(wishlistCard).join("");
    if(empty)empty.hidden=items.length>0;
    const itemLabel=root.dataset.itemsLabel||'items';
    countEls.forEach(el=>{el.textContent=`${items.length} ${items.length===1?'item':itemLabel}`});
    updateSelected();
    store.refreshWishlist();
  }
  root.addEventListener("change",e=>{
    if(e.target.matches("[data-wishlist-select-all]")){
      root.querySelectorAll("[data-wishlist-select]").forEach(input=>{input.checked=e.target.checked});
      updateSelected();
    }
    if(e.target.matches("[data-wishlist-select]"))updateSelected();
  });
  root.addEventListener("click",async e=>{
    const remove=e.target.closest("[data-wishlist-remove]");
    if(remove){
      e.preventDefault();
      store.remove("wishlist",remove.dataset.wishlistRemove);
      render();
      notify("Removed from wishlist");
      return;
    }
    const move=e.target.closest("[data-wishlist-move]");
    if(move){
      e.preventDefault();
      const item=getItems().find(x=>String(x.id)===String(move.dataset.wishlistMove));
      if(!item?.variantId){
        notify("This item needs a product variant before it can move to cart");
        return;
      }
      move.disabled=true;
      const added=await addToCartAjax(item.variantId,1);
      move.disabled=false;
      if(added){
        store.remove("wishlist",item.id);
        render();
        notify("Moved to cart");
      }else{
        notify("Could not move item to cart. Please try again.");
      }
    }
  });
  document.querySelectorAll("[data-wishlist-share]").forEach(button=>button.addEventListener("click",async()=>{
    const shareData={title:document.title,url:location.href};
    if(navigator.share){
      try{
        await navigator.share(shareData);
        notify("Wishlist shared");
        return;
      }catch(e){}
    }
    try{await navigator.clipboard.writeText(location.href);notify("Wishlist link copied")}catch(e){notify("Copy failed. Use your browser address bar to copy the link.")}
  }));
  document.querySelectorAll("[data-wishlist-move-all]").forEach(button=>button.addEventListener("click",async()=>{
    const selected=[...root.querySelectorAll("[data-wishlist-select]:checked")].map(x=>x.value);
    const items=getItems().filter(x=>!selected.length||selected.includes(String(x.id))).filter(item=>item.variantId);
    if(!items.length){
      notify("No wishlist items are ready to move to cart");
      return;
    }
    button.disabled=true;
    let moved=0;
    for(const item of items){
      const added=await addToCartAjax(item.variantId,1);
      if(added){
        moved+=1;
        store.remove("wishlist",item.id);
      }
    }
    button.disabled=false;
    render();
    notify(moved?`${moved} ${moved===1?'item':'items'} moved to cart`:"Could not move items to cart. Please try again.");
  }));
  render();
}
function initGift(){
  const root=document.querySelector("[data-gift-builder]");
  if(!root)return;
  const centerEl=root.querySelector("[data-gift-centerpieces]");
  const complementsEl=root.querySelector("[data-gift-complements]");
  const emptyEl=root.querySelector("[data-gift-empty]");
  const summaryEl=root.querySelector("[data-gift-summary]");
  const totalEl=root.querySelector("[data-gift-total]");
  const centerLabel=root.querySelector("[data-gift-center-label]");
  const packLabel=root.querySelector("[data-gift-pack-label]");
  const accentViewAll=root.querySelector("[data-gift-accent-view-all]");
  const presetControls=document;
  let selectedCenterId="";
  let selectedPresetId=localStorage.getItem("ltv_gift_preset")||"default";
  let pack=[...root.querySelectorAll("[data-gift-pack]")].find(x=>x.classList.contains("is-selected"))||root.querySelector("[data-gift-pack]");
  let centerEditMode=false;

  const money=n=>"Rs. "+(Number(n)||0).toLocaleString("en-IN",{maximumFractionDigits:0});
  const image=item=>item.image||"";
  const price=item=>Number(String(item.price||0).replace(/[^0-9.]/g,""))||0;
  const qty=item=>Math.max(1,Number(item.qty||1));
  const getItems=()=>store.get("gift").filter(item=>item.id!=="custom-gift");
  const removeGift=id=>{store.set("gift",store.get("gift").filter(item=>item.id!==id))};
  const updateGiftQty=(id,delta)=>{
    const items=store.get("gift");
    const next=items.map(item=>{
      if(String(item.id)!==String(id))return item;
      return {...item,qty:Math.max(1,qty(item)+delta)};
    });
    store.set("gift",next);
  };
  const itemFromDataset=data=>({id:data.id,title:data.title,price:price(data),image:data.image,url:data.url,variantId:data.variantId,artisan:data.artisan,sourceKey:data.sourceKey||data.id});
  const cssSafe=value=>window.CSS?.escape?CSS.escape(String(value||"")):String(value||"").replace(/["\\]/g,"\\$&");
  const itemsFromSource=source=>[...(source?.querySelectorAll("[data-gift-accent-option]")||[])].map(button=>itemFromDataset(button.dataset));
  const uniqueById=items=>{
    const seen=new Set();
    return items.filter(item=>{
      if(!item.id||seen.has(item.id))return false;
      seen.add(item.id);
      return true;
    });
  };
  const card=item=>`<article class="ltv-option ltv-gift-product-option ${item.id===selectedCenterId?"is-selected":""}" role="button" tabindex="0" data-gift-center="${item.id}">
    ${image(item)?`<img src="${image(item)}" alt="${item.title||"Gift product"}" loading="lazy" decoding="async">`:''}
    ${qty(item)>1?`<span class="ltv-gift-qty">x${qty(item)}</span>`:""}
    <h4>${item.title||"Gift product"}</h4>
    <p>${item.artisan?`By ${item.artisan}`:""}</p>
    <strong>${money(price(item)*qty(item))}</strong>
    ${centerEditMode?`<span class="ltv-gift-quantity-editor" role="group" aria-label="Edit quantity for ${item.title||"product"}">
      <button type="button" data-gift-qty-step="-1" data-gift-qty-id="${item.id}" aria-label="Decrease quantity">-</button>
      <b>${qty(item)}</b>
      <button type="button" data-gift-qty-step="1" data-gift-qty-id="${item.id}" aria-label="Increase quantity">+</button>
    </span>`:`<span class="ltv-gift-remove" role="button" tabindex="0" data-gift-remove="${item.id}" aria-label="Remove ${item.title||"product"}">Remove</span>`}
  </article>`;
  const accentCard=item=>`<button type="button" class="ltv-option ltv-gift-product-option ${item.inGift?"is-selected":""}" data-gift-accent-add data-id="${item.id}" data-title="${item.title||""}" data-price="${price(item)}" data-image="${image(item)}" data-url="${item.url||""}" data-variant-id="${item.variantId||""}" data-artisan="${item.artisan||""}">
    ${image(item)?`<img src="${image(item)}" alt="${item.title||"Accent product"}" loading="lazy" decoding="async">`:''}
    ${item.inGift?`<span class="ltv-gift-selected-mark" aria-hidden="true"><iconify-icon icon="lucide:check"></iconify-icon></span>`:''}
    ${qty(item)>1?`<span class="ltv-gift-qty">x${qty(item)}</span>`:""}
    <h4>${item.title||"Accent product"}</h4>
    <p>${item.artisan?`By ${item.artisan}`:""}</p>
    <strong>${money(price(item)*qty(item))}</strong>
    ${item.inGift?`<span class="ltv-gift-remove" role="button" tabindex="0" data-gift-remove="${item.id}" aria-label="Remove ${item.title||"product"}">Remove</span>`:'<span class="ltv-gift-add-accent">Add Accent</span>'}
  </button>`;
  const sourceAccents=(center,selectedIds,selectedAccents=[])=>{
    const centerKey=center?.sourceKey||center?.id||"";
    let source=centerKey?root.querySelector(`[data-gift-center-source="${cssSafe(centerKey)}"]`):null;
    let options=uniqueById(itemsFromSource(source)).filter(item=>item.id!==center?.id);
    if(!options.length){
      source=[...root.querySelectorAll("[data-gift-accent-source]")].find(el=>el.dataset.giftAccentSource===selectedPresetId);
      options=uniqueById(itemsFromSource(source)).filter(item=>item.id!==center?.id);
    }
    if(!options.length){
      source=root.querySelector('[data-gift-accent-source="default"]');
      options=uniqueById(itemsFromSource(source)).filter(item=>item.id!==center?.id);
    }
    if(!options.length){
      source=root.querySelector("[data-gift-fallback-source]");
      options=uniqueById(itemsFromSource(source)).filter(item=>item.id!==center?.id);
    }
    if(accentViewAll&&source?.dataset.accentUrl){
      accentViewAll.href=source.dataset.accentUrl;
      accentViewAll.hidden=false;
    }else if(accentViewAll){
      accentViewAll.hidden=true;
    }
    const selectedAccentIds=new Set(selectedAccents.map(item=>item.id));
    const merged=uniqueById([...options,...selectedAccents]).filter(item=>item.id!==center?.id);
    return merged.map(item=>({...item,inGift:selectedAccentIds.has(item.id)||selectedIds.has(item.id)}));
  };

  function selectedPack(){
    return pack?{title:pack.dataset.title||"Gift packaging",price:price(pack.dataset),image:pack.dataset.image||"",variantId:pack.dataset.variantId||""}:{title:"",price:0,image:"",variantId:""};
  }

  function giftDetails(){
    return {
      recipient:root.querySelector("[data-gift-recipient]")?.value?.trim()||"",
      message:root.querySelector("[data-gift-message]")?.value?.trim()||"",
      deliveryDate:root.querySelector("[data-gift-delivery-date]")?.value||""
    };
  }

  function cartTarget(button){
    const target=(button?.dataset.cartUrl||"/cart").trim();
    return target||"/cart";
  }

  function giftLineProperties(role,packItem,details){
    const properties={
      "_Gift builder":"Yes",
      "Gift bundle":"Yes",
      "Gift role":role
    };
    if(packItem?.title)properties["Gift packaging"]=packItem.title;
    if(details.recipient)properties["Recipient"]=details.recipient;
    if(details.message)properties["Gift message"]=details.message;
    if(details.deliveryDate)properties["Preferred delivery date"]=details.deliveryDate;
    return properties;
  }

  function buildGiftCartPayload(items,packItem,details){
    const cartItems=items
      .filter(item=>/^\d+$/.test(String(item.variantId||"")))
      .map(item=>({
        id:Number(item.variantId),
        quantity:qty(item),
        properties:{
          ...giftLineProperties(item.id===selectedCenterId?"Centerpiece":"Accent",packItem,details),
          "_Gift item title":item.title||""
        }
      }));
    if(/^\d+$/.test(String(packItem.variantId||""))){
      cartItems.push({
        id:Number(packItem.variantId),
        quantity:1,
        properties:giftLineProperties("Packaging",packItem,details)
      });
    }
    return cartItems;
  }

  function applyPreset(button){
    centerEl?.classList.add("is-updating");
    complementsEl?.classList.add("is-updating");
    selectedPresetId=button?.dataset.giftPreset||"default";
    localStorage.setItem("ltv_gift_preset",selectedPresetId);
    if(button?.dataset.id){
      const item=itemFromDataset(button.dataset);
      selectedCenterId=item.id;
      store.set("gift",[item]);
      render();
      requestAnimationFrame(()=>{centerEl?.classList.remove("is-updating");complementsEl?.classList.remove("is-updating");});
      return;
    }
    selectedCenterId="";
    store.set("gift",[]);
    render();
    requestAnimationFrame(()=>{centerEl?.classList.remove("is-updating");complementsEl?.classList.remove("is-updating");});
  }

  function render(){
    const items=getItems();
    if(!items.length)centerEditMode=false;
    document.querySelectorAll("[data-gift-preset]").forEach(button=>button.classList.toggle("is-selected",button.dataset.giftPreset===selectedPresetId));
    if(!selectedCenterId||!items.some(item=>item.id===selectedCenterId))selectedCenterId=items[0]?.id||"";
    const center=items.find(item=>item.id===selectedCenterId);
    const selectedAccents=items.filter(item=>item.id!==selectedCenterId);
    const selectedIds=new Set(items.map(item=>item.id));
    const accentOptions=sourceAccents(center,selectedIds,selectedAccents);
    if(centerEl)centerEl.innerHTML=center?card(center):"";
    if(complementsEl)complementsEl.innerHTML=accentOptions.length?accentOptions.map(accentCard).join(""):'<p class="ltv-gift-note">Choose an accent collection in this section settings or add more bundle-ready products from the collection.</p>';
    if(emptyEl)emptyEl.hidden=items.length>0;
    const packItem=selectedPack();
    const sum=(center?price(center)*qty(center):0)+selectedAccents.reduce((s,item)=>s+price(item)*qty(item),0)+(packItem.title?packItem.price:0);
    if(totalEl)totalEl.textContent=money(sum);
    document.querySelectorAll("[data-gift-bundle-total]").forEach(el=>{el.textContent=money(sum)});
    document.querySelectorAll("[data-gift-bundle-bar]").forEach(bar=>{
      bar.hidden=items.length===0;
      bar.classList.toggle("is-visible",items.length>0);
    });
    document.querySelectorAll("[data-gift-bundle-count]").forEach(el=>{el.textContent=items.reduce((n,item)=>n+qty(item),0)});
    updateStickyBar();
    if(centerLabel)centerLabel.textContent=center?`${center.title} (${money(price(center)*qty(center))})`:"Select a product from your gift builder.";
    if(packLabel&&packItem.title)packLabel.textContent=`${packItem.title} (${money(packItem.price)})`;
    const centerToggle=centerEl?.closest(".ltv-gift-step")?.querySelector("[data-gift-step-toggle]");
    if(centerToggle)centerToggle.textContent=centerEditMode?"Save":"Edit";
    if(summaryEl){
      const summaryRow=(type,item,emptyText="Select item")=>`<div class="ltv-gift-summary-row ${!item?"is-empty":""}">${item&&image(item)?`<img src="${image(item)}" width="56" height="56" alt="" loading="lazy" decoding="async">`:`<span><iconify-icon icon="lucide:package-plus"></iconify-icon></span>`}<div><small>${type}</small><h4>${item?`${item.title}${qty(item)>1?` <em>x${qty(item)}</em>`:""}`:emptyText}</h4>${item?`<strong>${money(price(item)*qty(item))}</strong>`:""}</div>${item&&type!=="Packaging"?`<button type="button" data-gift-remove="${item.id}" aria-label="Remove ${item.title}"><iconify-icon icon="lucide:x"></iconify-icon></button>`:""}</div>`;
      summaryEl.innerHTML=`${summaryRow("Centerpiece",center,"Select Centerpiece")}${summaryRow("Accent",selectedAccents[0],"Select Accent")}${packItem.title?summaryRow("Packaging",packItem):""}`;
    }
  }

  root.querySelectorAll(".ltv-step__head").forEach(h=>h.addEventListener("click",e=>{if(!e.target.closest("button"))h.parentElement.classList.toggle("is-open")}));
  presetControls.addEventListener("click",e=>{
    const blank=e.target.closest("[data-gift-start-blank]");
    if(blank){
      e.preventDefault();
      selectedPresetId="default";
      localStorage.removeItem("ltv_gift_preset");
      selectedCenterId="";
      centerEl?.classList.add("is-updating");
      complementsEl?.classList.add("is-updating");
      store.set("gift",[]);
      render();
      requestAnimationFrame(()=>{centerEl?.classList.remove("is-updating");complementsEl?.classList.remove("is-updating");});
      return;
    }
    const preset=e.target.closest("[data-gift-preset]");
    if(preset){
      e.preventDefault();
      applyPreset(preset);
    }
  });
  root.addEventListener("click",e=>{
    const stepToggle=e.target.closest("[data-gift-step-toggle]");
    if(stepToggle){
      const step=stepToggle.closest(".ltv-gift-step");
      if(step?.querySelector("[data-gift-centerpieces]")){
        e.preventDefault();
        centerEditMode=!centerEditMode;
        step.classList.add("is-open");
        render();
        return;
      }
      if(step){
        e.preventDefault();
        step.classList.toggle("is-open");
        const icon=stepToggle.querySelector("iconify-icon");
        if(icon)icon.setAttribute("icon",step.classList.contains("is-open")?"lucide:chevron-up":"lucide:chevron-down");
        else stepToggle.textContent=step.classList.contains("is-open")?"Save":"Edit";
        return;
      }
    }
    const qtyButton=e.target.closest("[data-gift-qty-step]");
    if(qtyButton){
      e.preventDefault();
      e.stopPropagation();
      updateGiftQty(qtyButton.dataset.giftQtyId,Number(qtyButton.dataset.giftQtyStep||0));
      render();
      return;
    }
    const remove=e.target.closest("[data-gift-remove]");
    if(remove){
      e.preventDefault();
      e.stopPropagation();
      removeGift(remove.dataset.giftRemove);
      render();
      return;
    }
    const center=e.target.closest("[data-gift-center]");
    if(center){
      selectedCenterId=center.dataset.giftCenter;
      render();
      return;
    }
    const accent=e.target.closest("[data-gift-accent-add]");
    if(accent){
      if(accent.classList.contains("is-selected"))return;
      store.add("gift",{id:accent.dataset.id,title:accent.dataset.title,price:price(accent.dataset),image:accent.dataset.image,url:accent.dataset.url,variantId:accent.dataset.variantId,artisan:accent.dataset.artisan});
      notify("Accent added to gift builder");
      render();
      return;
    }
    const packButton=e.target.closest("[data-gift-pack]");
    if(packButton){
      pack=packButton;
      root.querySelectorAll("[data-gift-pack]").forEach(x=>x.classList.toggle("is-selected",x===packButton));
      render();
    }
  });
  root.querySelector("[data-gift-add-cart]")?.addEventListener("click",async e=>{
    const button=e.currentTarget;
    const items=getItems();
    if(!items.length){notify("Add a product to your gift builder first");return;}
    const packItem=selectedPack();
    const details=giftDetails();
    const missingVariants=items.filter(item=>!/^\d+$/.test(String(item.variantId||"")));
    if(missingVariants.length){
      notify("Some selected gift products need valid Shopify variants before adding to cart.");
      return;
    }
    if(!/^\d+$/.test(String(packItem.variantId||""))){
      notify("Please connect the selected presentation to a Shopify product first.");
      return;
    }
    const cartItems=buildGiftCartPayload(items,packItem,details);
    if(cartItems.length!==items.length+1){
      notify("Could not prepare the complete gift bundle for cart.");
      return;
    }
    button.disabled=true;
    button.classList.add("is-loading");
    const giftProducts=items.map(item=>`${item.title||"Gift product"} x${qty(item)}`).join(", ");
    const giftTotal=(totalEl?.textContent||"").trim();
    const attributes={
      "Gift builder":"Yes",
      "Gift products":giftProducts,
      "Gift packaging":packItem.title||"",
      "Gift estimated total":giftTotal,
      "Gift recipient":details.recipient,
      "Gift message":details.message,
      "Gift preferred delivery date":details.deliveryDate
    };
    const note=[
      "Gift builder order",
      giftProducts?`Products: ${giftProducts}`:"",
      packItem.title?`Packaging: ${packItem.title}`:"",
      details.recipient?`Recipient: ${details.recipient}`:"",
      details.deliveryDate?`Preferred delivery date: ${details.deliveryDate}`:"",
      details.message?`Gift message: ${details.message}`:""
    ].filter(Boolean).join("\n");
    const added=await addItemsToCartAjax(cartItems);
    if(!added){
      button.disabled=false;
      button.classList.remove("is-loading");
      notify("Could not add this gift to cart. Please try again.");
      return;
    }
    await updateCartGiftAttributes(attributes,note);
    store.set("gift",[]);
    notify("Gift added. Opening cart...");
    window.location.href=cartTarget(button);
  });
  root.querySelector("[data-gift-summary-toggle]")?.addEventListener("click",e=>{
    const summary=e.currentTarget.closest(".ltv-gift-summary");
    summary?.classList.toggle("is-expanded");
  });
  render();
}
function initPreferences(){
  const root=document.querySelector("[data-preferences]");
  if(!root)return;
  const language=root.querySelector("[data-pref-language]");
  const currency=root.querySelector("[data-pref-currency]");
  try{
    const saved=JSON.parse(localStorage.getItem("ltv_prefs")||"{}");
    if(saved.language&&language)language.value=saved.language;
    if(saved.currency&&currency)currency.value=saved.currency;
  }catch(e){}
  root.querySelector("[data-pref-save]")?.addEventListener("click",()=>{
    localStorage.setItem("ltv_prefs",JSON.stringify({language:language?.value||"EN",currency:currency?.value||"INR"}));
    notify("Preferences saved");
  });
}
function initSearch(){
  const root=document.querySelector("[data-search-results]");
  if(!root) return;
  const q=new URLSearchParams(location.search).get("q")||"Blue Pottery";
  const queryInput=root.querySelector("[data-search-query]");
  if(queryInput) queryInput.value=q;
  const labelEl=root.querySelector("[data-search-label]");
  if(labelEl) labelEl.textContent=q;
  const resultsEl=root.querySelector("[data-results]");
  if(resultsEl&&!resultsEl.innerHTML.trim()){
    const products=catalogProductsFromDom();
    const matches=products.filter(p=>(p.title+p.craft+p.city+p.artisan).toLowerCase().includes(q.toLowerCase()));
    resultsEl.innerHTML=(matches.length?matches:products.slice(0,6)).map(productCard).join("");
  }
  const filters=root.querySelector("[data-search-filters]");
  const toggle=root.querySelector("[data-search-filter-toggle]");
  const close=root.querySelector("[data-search-filter-close]");
  const tabs=[...root.querySelectorAll("[data-search-tab]")];
  const panels=[...root.querySelectorAll("[data-search-panel]")];
  const viewInputs=[...root.querySelectorAll("[data-search-view-input]")];
  const summary=root.querySelector("[data-search-summary]");
  const loadMore=root.querySelector("[data-search-load-more]");
  const params=new URLSearchParams(location.search);
  const productTab=()=>tabs.find(item=>item.dataset.searchTab==="products");
  const productCards=()=>[...root.querySelectorAll('.ltv-search-product-grid [data-product-card]')];
  const priceFilters=[...root.querySelectorAll("[data-search-price-filter]")];
  const scopedFilters=[...root.querySelectorAll("[data-search-filter-scope]")];
  const scopedSorts=[...root.querySelectorAll("[data-search-sort-scope]")];
  const smartFilters=[...root.querySelectorAll("[data-search-smart-filter]")];
  const bundleToggle=root.querySelector("[data-search-bundle-toggle]");
  const productPrice=card=>Number(String(card.dataset.price||"").replace(/[^0-9.]/g,""))||0;
  const activeView=()=>tabs.find(item=>item.classList.contains("is-active"))?.dataset.searchTab||tabs[0]?.dataset.searchTab||"products";
  const visibleScopedFilterCount=view=>scopedFilters.filter(item=>{
    const scopes=String(item.dataset.searchFilterScope||"").split(",").map(scope=>scope.trim());
    return scopes.includes(view)&&item.querySelector('input:not([disabled]), a, button');
  }).length;
  const setFilterScopes=view=>{
    scopedFilters.forEach(item=>{
      const scopes=String(item.dataset.searchFilterScope||"").split(",").map(scope=>scope.trim());
      item.hidden=!scopes.includes(view);
    });
    scopedSorts.forEach(item=>{
      const scopes=String(item.dataset.searchSortScope||"").split(",").map(scope=>scope.trim());
      item.hidden=!scopes.includes(view);
    });
  };
  const setFilterPanelState=view=>{
    const tab=tabs.find(item=>item.dataset.searchTab===view);
    const shouldHide=Number(tab?.dataset.searchCount||0)===0||visibleScopedFilterCount(view)===0;
    if(filters)filters.hidden=shouldHide;
    if(toggle)toggle.hidden=shouldHide;
  };
  const setTabCount=(view,count)=>{
    const tab=tabs.find(item=>item.dataset.searchTab===view);
    if(tab){
      tab.dataset.searchCount=String(count);
      tab.querySelector("small")&&(tab.querySelector("small").textContent=String(count));
    }
    if(loadMore&&activeView()===view){
      loadMore.hidden=count<=15;
    }
    if(summary&&activeView()===view){
      summary.innerHTML=`${summary.dataset.prefix||"Showing"} ${count} ${summary.dataset.suffix||"matches for"} <strong>"${summary.dataset.query||q}"</strong>`;
    }
    if(activeView()===view)setFilterPanelState(view);
  };
  const setSearchView=(view,updateUrl=true)=>{
    const tab=tabs.find(item=>item.dataset.searchTab===view)||tabs[0];
    if(!tab)return;
    const nextView=tab.dataset.searchTab;
    tabs.forEach(item=>item.classList.toggle("is-active",item===tab));
    panels.forEach(panel=>{
      panel.hidden=panel.dataset.searchPanel!==nextView;
    });
    viewInputs.forEach(input=>{input.value=nextView;});
    setFilterScopes(nextView);
    if(summary){
      const count=tab.dataset.searchCount||"0";
      summary.innerHTML=`${summary.dataset.prefix||"Showing"} ${count} ${summary.dataset.suffix||"matches for"} <strong>"${summary.dataset.query||q}"</strong>`;
    }
    if(loadMore){
      loadMore.hidden=Number(tab.dataset.searchCount||0)<=15;
    }
    setFilterPanelState(nextView);
    if(updateUrl){
      const url=new URL(location.href);
      url.searchParams.set("view",nextView);
      history.replaceState({}, "", url);
    }
  };
  if(tabs.length){
    tabs.forEach(tab=>{
      tab.addEventListener("click",event=>{
        event.preventDefault();
        setSearchView(tab.dataset.searchTab);
      });
    });
    setSearchView(params.get("view")||tabs.find(tab=>tab.classList.contains("is-active"))?.dataset.searchTab||tabs[0].dataset.searchTab,false);
  }
  const activePriceFilter=()=>priceFilters.find(input=>input.checked)||priceFilters[0];
  const applyProductFilters=(input=activePriceFilter(),updateUrl=true)=>{
    input=input||{value:"",dataset:{}};
    const min=Number(input.dataset.priceMin||0);
    const max=input.dataset.priceMax===""||input.dataset.priceMax==null?Infinity:Number(input.dataset.priceMax);
    let visible=0;
    const bundleOnly=Boolean(bundleToggle?.checked);
    productCards().forEach(card=>{
      const price=productPrice(card);
      const passesPrice=!input.value||(price>=min&&price<=max);
      const passesBundle=!bundleOnly||card.dataset.bundleReady!=="false";
      const show=passesPrice&&passesBundle;
      card.hidden=!show;
      if(show)visible++;
    });
    setTabCount("products",visible);
    if(updateUrl){
      const url=new URL(location.href);
      if(input.value){
        if(input.dataset.priceMin)url.searchParams.set("price_min",input.dataset.priceMin);else url.searchParams.delete("price_min");
        if(input.dataset.priceMax)url.searchParams.set("price_max",input.dataset.priceMax);else url.searchParams.delete("price_max");
        url.searchParams.set("view","products");
      }else{
        url.searchParams.delete("price_min");
        url.searchParams.delete("price_max");
      }
      history.replaceState({}, "", url);
    }
  };
  if(priceFilters.length){
    const minParam=params.get("price_min")||"";
    const maxParam=params.get("price_max")||"";
    const active=priceFilters.find(input=>(input.dataset.priceMin||"")===minParam&&(input.dataset.priceMax||"")===maxParam)||priceFilters[0];
    active.checked=true;
    applyProductFilters(active,false);
    priceFilters.forEach(input=>{
      input.addEventListener("change",()=>{
        applyProductFilters(input);
        setSearchView("products");
      });
    });
  }
  const applySmartFilters=(view=activeView())=>{
    const viewFilters=smartFilters.filter(input=>input.dataset.searchSmartView===view);
    if(!viewFilters.length)return;
    const groups={};
    viewFilters.forEach(input=>{
      if(input.checked){
        const group=input.dataset.searchSmartGroup||"default";
        groups[group]??=new Set();
        groups[group].add(input.value);
      }
    });
    let visible=0;
    root.querySelectorAll(`[data-search-smart-card="${view}"]`).forEach(card=>{
      const show=Object.entries(groups).every(([group,values])=>{
        if(!values.size)return true;
        return values.has(card.dataset[`searchSmart${group.charAt(0).toUpperCase()+group.slice(1)}`]||"");
      });
      card.hidden=!show;
      if(show)visible++;
    });
    setTabCount(view,visible);
  };
  smartFilters.forEach(input=>{
    input.addEventListener("change",()=>{
      const view=input.dataset.searchSmartView||activeView();
      applySmartFilters(view);
      setSearchView(view);
    });
  });
  toggle?.addEventListener("click",()=>{
    const next=!filters?.classList.contains("is-open");
    filters?.classList.toggle("is-open",next);
    toggle.setAttribute("aria-expanded",String(next));
  });
  close?.addEventListener("click",()=>{
    filters?.classList.remove("is-open");
    toggle?.setAttribute("aria-expanded","false");
  });
  root.querySelector(".ltv-search-mobile-controls select")?.addEventListener("change",e=>{
    const form=root.querySelector(".ltv-search-toolbar form");
    const select=form?.querySelector('select[name="sort_by"]');
    if(select&&form){
      select.value=e.target.value;
      form.submit();
    }
  });
  if(bundleToggle){
    bundleToggle.checked=params.get("bundle_ready")==="1";
    root.classList.toggle("is-bundle-filter-active",bundleToggle.checked);
    applyProductFilters(activePriceFilter(),false);
  }
  bundleToggle?.addEventListener("change",e=>{
    root.classList.toggle("is-bundle-filter-active",e.target.checked);
    applyProductFilters(activePriceFilter(),false);
    const url=new URL(location.href);
    if(e.target.checked) url.searchParams.set("bundle_ready","1");
    else url.searchParams.delete("bundle_ready");
    history.replaceState({}, "", url);
  });
}
function initSiteSearchSuggestions(){
  const forms=[...document.querySelectorAll("[data-ltv-site-search-form]")];
  if(!forms.length)return;
  const cache=new Map();
  const typeLabels={products:"Product",collections:"Collection",pages:"Page",articles:"Story"};
  const resultGroups=["products","collections","pages","articles"];
  const normalize=value=>String(value||"").trim();
  const normalizeSearch=value=>String(value||"").toLowerCase().replace(/<[^>]+>/g," ").replace(/[^a-z0-9\s]/g," ").replace(/\s+/g," ").trim();
  const searchUrl=query=>`/search?q=${encodeURIComponent(query)}&type=product,page,article&view=products`;
  const localSuggestions=query=>{
    const normalizedQuery=normalizeSearch(query);
    if(!normalizedQuery)return[];
    return [...document.querySelectorAll("[data-ltv-site-search-source] [data-ltv-site-search-item]")]
      .map(item=>{
        const title=item.dataset.ltvSiteSearchTitle||item.textContent||"";
        const text=item.dataset.ltvSiteSearchText||"";
        const haystack=normalizeSearch(`${title} ${text}`);
        let score=99;
        const normalizedTitle=normalizeSearch(title);
        if(normalizedTitle===normalizedQuery)score=0;
        else if(normalizedTitle.startsWith(normalizedQuery))score=1;
        else if(normalizedTitle.split(" ").some(word=>word.startsWith(normalizedQuery)))score=2;
        else if(haystack.includes(normalizedQuery))score=3;
        return {
          title,
          url:item.dataset.ltvSiteSearchUrl||item.getAttribute("href")||searchUrl(title||query),
          type:item.dataset.ltvSiteSearchType||"Result",
          text,
          image:item.dataset.ltvSiteSearchImage||"",
          score
        };
      })
      .filter(item=>item.score<99)
      .sort((a,b)=>a.score-b.score||a.title.length-b.title.length)
      .slice(0,6);
  };
  const suggestionUrl=query=>{
    const params=new URLSearchParams();
    params.set("q",query);
    params.set("resources[type]","product,collection,page,article");
    params.set("resources[limit]","8");
    params.set("resources[options][unavailable_products]","last");
    params.set("resources[options][fields]","title,product_type,variants.title,vendor,body");
    return `/search/suggest.json?${params.toString()}`;
  };
  const toSuggestion=(item,group,query)=>({
    title:item.title||item.name||query,
    url:item.url||searchUrl(item.title||query),
    type:typeLabels[group]||"Result",
    text:item.vendor||item.product_type||item.excerpt||item.body||"",
    image:item.featured_image?.url||item.image||item.featured_image||""
  });
  const fetchSuggestions=async query=>{
    if(cache.has(query))return cache.get(query);
    const local=localSuggestions(query);
    let remote=[];
    try{
      const response=await fetch(suggestionUrl(query),{headers:{Accept:"application/json"}});
      if(response.ok){
        const data=await response.json();
        const results=data?.resources?.results||{};
        remote=resultGroups.flatMap(group=>(results[group]||[]).map(item=>toSuggestion(item,group,query)));
      }
    }catch(e){}
    const seen=new Set();
    const suggestions=[...local,...remote].filter(item=>{
      const key=`${item.type}:${item.url||item.title}`.toLowerCase();
      if(seen.has(key))return false;
      seen.add(key);
      return true;
    }).slice(0,8);
    if(!suggestions.length){
      suggestions.push({title:query,url:searchUrl(query),type:"Search",text:"Search all products, cities, artisans, and stories"});
    }
    cache.set(query,suggestions);
    return suggestions;
  };
  forms.forEach((form,formIndex)=>{
    const input=form.querySelector("[data-ltv-site-search-input]");
    const box=form.querySelector("[data-ltv-site-search-suggestions]");
    if(!input||!box)return;
    if(!box.id)box.id=`LtvSiteSearchSuggestions-${formIndex}`;
    input.setAttribute("aria-controls",box.id);
    let activeController=null;
    let suggestions=[];
    let timer=0;
    const hide=()=>{
      suggestions=[];
      box.hidden=true;
      box.innerHTML="";
      input.setAttribute("aria-expanded","false");
    };
    const render=items=>{
      suggestions=items;
      box.innerHTML=items.map((item,index)=>`
        <a class="ltv-site-search-suggestion" href="${esc(item.url)}" role="option" data-ltv-site-search-option="${index}">
          ${item.image?`<span class="ltv-site-search-suggestion__image"><img src="${esc(item.image)}" alt="" loading="lazy"></span>`:""}
          <span class="ltv-site-search-suggestion__copy">
            <strong>${esc(item.title)}</strong>
            <small>${esc(item.type)}${item.text?` · ${esc(String(item.text).replace(/<[^>]+>/g,"").slice(0,80))}`:""}</small>
          </span>
        </a>
      `).join("");
      box.hidden=false;
      input.setAttribute("aria-expanded","true");
    };
    const update=()=>{
      const query=normalize(input.value);
      window.clearTimeout(timer);
      if(query.length<2){
        hide();
        return;
      }
      timer=window.setTimeout(async()=>{
        try{
          activeController?.abort();
          activeController=new AbortController();
          const items=await fetchSuggestions(query);
          if(normalize(input.value)===query)render(items);
        }catch(e){
          hide();
        }
      },180);
    };
    input.addEventListener("input",update);
    input.addEventListener("focus",update);
    input.addEventListener("keydown",event=>{
      if(event.key==="Escape")hide();
      if(event.key==="ArrowDown"&&!box.hidden){
        event.preventDefault();
        box.querySelector("[data-ltv-site-search-option]")?.focus();
      }
    });
    box.addEventListener("keydown",event=>{
      if(event.key==="Escape"){
        hide();
        input.focus();
      }
    });
    form.addEventListener("submit",event=>{
      const query=normalize(input.value);
      if(!query){
        event.preventDefault();
        hide();
        return;
      }
      form.querySelector('input[name="type"]')?.setAttribute("value","product,page,article");
    });
    document.addEventListener("click",event=>{
      if(!form.contains(event.target))hide();
    });
  });
  document.addEventListener("keydown",event=>{
    if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==="k"){
      const candidates=[
        ...document.querySelectorAll("main [data-ltv-site-search-input]"),
        ...document.querySelectorAll("[data-ltv-site-search-input]")
      ];
      const input=candidates.find(item=>item.offsetParent!==null&&!item.disabled)||candidates[0];
      if(input){
        event.preventDefault();
        input.focus();
      }
    }
  });
}
function initFaq(){
  document.querySelectorAll("[data-faq-root]").forEach(root=>{
    const topics=[...root.querySelectorAll("[data-faq-topic]")];
    const panels=[...root.querySelectorAll("[data-faq-panel]")];
    const search=document.querySelector("[data-faq-search]");
    const searchForm=document.querySelector("[data-faq-search-form]");
    const emptyState=root.querySelector("[data-faq-empty]");
    const desktopCount=Number(root.dataset.collapsedCount||2);
    const mobileCount=Number(root.dataset.mobileCollapsedCount||4);
    const count=()=>window.matchMedia("(max-width: 760px)").matches?mobileCount:desktopCount;
    const hasSearch=()=>Boolean((search?.value||"").trim());
    const suggestionsBox=document.querySelector("[data-faq-suggestions]");
    let visibleSuggestions=[];
    const normalize=value=>String(value||"").toLowerCase().replace(/[^a-z0-9\s]/g," ").replace(/\s+/g," ").trim();
    const topicLabel=topic=>topics.find(button=>button.dataset.faqTopic===topic)?.textContent?.trim()||"FAQ";
    const suggestionIndex=(()=>{
      const byKey=new Map();
      const add=item=>{
        const title=String(item.title||"").trim();
        if(!title)return;
        const key=`${item.type||"faq"}:${normalize(title)}`;
        if(!byKey.has(key))byKey.set(key,{...item,title,haystack:normalize([title,item.meta,item.text].filter(Boolean).join(" "))});
      };
      panels.forEach(panel=>{
        const topic=panel.dataset.faqPanel;
        add({type:"topic",title:topicLabel(topic),meta:"FAQ topic",topic});
        panel.querySelectorAll("[data-faq-item]").forEach(item=>{
          const title=item.querySelector("summary span")?.childNodes?.[0]?.textContent?.trim()||item.querySelector("summary")?.textContent?.trim()||"";
          add({type:"faq",title,meta:`Answer in ${topicLabel(topic)}`,text:item.textContent,topic,element:item});
        });
      });
      document.querySelectorAll("[data-faq-suggestion-source] [data-faq-suggestion]").forEach(item=>{
        const title=item.dataset.faqSuggestionText||item.textContent;
        add({type:item.dataset.faqSuggestion||"product",title,meta:item.dataset.faqSuggestion==="collection"?"Collection":"Product search",url:item.getAttribute("href")});
      });
      return [...byKey.values()];
    })();

    function activePanel(){
      return panels.find(panel=>panel.classList.contains("is-active"))||panels[0];
    }

    function suggestionScore(item,query){
      if(!query)return 99;
      const title=normalize(item.title);
      const words=title.split(" ");
      if(title===query)return 0;
      if(title.startsWith(query))return 1;
      if(words.some(word=>word.startsWith(query)))return 2;
      if(title.includes(query))return 3;
      if(item.haystack.includes(query))return 4;
      return 99;
    }

    function hideSuggestions(){
      visibleSuggestions=[];
      if(suggestionsBox){
        suggestionsBox.hidden=true;
        suggestionsBox.innerHTML="";
      }
      search?.setAttribute("aria-expanded","false");
    }

    function renderSuggestions(){
      if(!search||!suggestionsBox)return;
      const query=normalize(search.value);
      if(query.length<2){
        hideSuggestions();
        return;
      }
      visibleSuggestions=suggestionIndex
        .map(item=>({...item,score:suggestionScore(item,query)}))
        .filter(item=>item.score<99)
        .sort((a,b)=>a.score-b.score||a.title.length-b.title.length)
        .slice(0,6);
      if(!visibleSuggestions.length){
        hideSuggestions();
        return;
      }
      suggestionsBox.innerHTML=visibleSuggestions.map((item,index)=>{
        const tag=item.url?"a":"button";
        const href=item.url?` href="${esc(item.url)}"`:"";
        const typeAttr=item.url?"":' type="button"';
        return `<${tag}${typeAttr}${href} class="ltv-faq-suggestion" role="option" data-faq-suggestion-select="${index}">
          <span>${esc(item.title)}</span>
          <small>${esc(item.meta||`Related to "${search.value.trim()}"`)}</small>
        </${tag}>`;
      }).join("");
      suggestionsBox.hidden=false;
      search.setAttribute("aria-expanded","true");
    }

    function chooseSuggestion(item){
      if(!item||!search)return;
      search.value=item.type==="topic"?"":item.title;
      hideSuggestions();
      if(item.url){
        window.location.href=item.url;
        return;
      }
      panels.forEach(panel=>panel.classList.add("is-expanded"));
      if(item.topic)setTopic(item.topic);
      filterSearch();
      panels.forEach(panel=>applyLimit(panel));
      if(item.element){
        item.element.hidden=false;
        item.element.setAttribute("open","");
        item.element.scrollIntoView({behavior:"smooth",block:"center"});
      }else{
        root.scrollIntoView({behavior:"smooth",block:"start"});
      }
    }

    function applyLimit(panel=activePanel()){
      if(!panel)return;
      const expanded=panel.classList.contains("is-expanded");
      const items=[...panel.querySelectorAll("[data-faq-item]")].filter(item=>!item.dataset.searchHidden);
      const max=count();
      let hidden=0;
      items.forEach((item,index)=>{
        const shouldHide=!hasSearch()&&!expanded&&index>=max;
        item.hidden=shouldHide;
        if(shouldHide)hidden++;
      });
      panel.classList.toggle("has-hidden",!hasSearch()&&hidden>0);
      const button=panel.querySelector("[data-faq-view-all]");
      if(button){
        button.innerHTML=`${expanded?button.dataset.lessLabel:button.dataset.moreLabel} <iconify-icon icon="lucide:arrow-right"></iconify-icon>`;
      }
    }

    function setTopic(topic){
      topics.forEach(button=>{
        const active=button.dataset.faqTopic===topic;
        button.classList.toggle("is-active",active);
        button.setAttribute("aria-pressed",String(active));
      });
      panels.forEach(panel=>{
        const active=panel.dataset.faqPanel===topic;
        panel.classList.toggle("is-active",active);
        if(!active)panel.classList.remove("is-expanded");
        panel.querySelectorAll("details[open]").forEach(item=>item.removeAttribute("open"));
      });
      filterSearch();
      applyLimit();
    }

    function filterSearch(){
      const query=(search?.value||"").trim().toLowerCase();
      let totalVisible=0;
      root.classList.toggle("is-searching",Boolean(query));
      panels.forEach(panel=>{
        let visible=0;
        panel.querySelectorAll("[data-faq-item]").forEach(item=>{
          const text=item.textContent.toLowerCase();
          const hide=Boolean(query)&&!text.includes(query);
          if(hide)item.dataset.searchHidden="true";
          else delete item.dataset.searchHidden;
          if(hide)item.hidden=true;
          else visible++;
        });
        totalVisible+=visible;
        panel.classList.toggle("is-search-empty",Boolean(query)&&visible===0);
      });
      topics.forEach(button=>{
        const panel=panels.find(item=>item.dataset.faqPanel===button.dataset.faqTopic);
        const matched=Boolean(query)&&panel&&!panel.classList.contains("is-search-empty");
        button.classList.toggle("is-search-match",matched);
      });
      if(emptyState)emptyState.hidden=!query||totalVisible>0;
    }

    topics.forEach(button=>button.addEventListener("click",()=>setTopic(button.dataset.faqTopic)));
    panels.forEach(panel=>{
      panel.querySelector("[data-faq-view-all]")?.addEventListener("click",()=>{
        panel.classList.toggle("is-expanded");
        applyLimit(panel);
      });
    });
    search?.addEventListener("input",()=>{
      panels.forEach(panel=>panel.classList.add("is-expanded"));
      filterSearch();
      panels.forEach(panel=>applyLimit(panel));
      renderSuggestions();
    });
    search?.addEventListener("focus",renderSuggestions);
    search?.addEventListener("keydown",e=>{
      if(e.key==="Escape")hideSuggestions();
    });
    suggestionsBox?.addEventListener("click",e=>{
      const option=e.target.closest("[data-faq-suggestion-select]");
      if(!option)return;
      const item=visibleSuggestions[Number(option.dataset.faqSuggestionSelect)];
      if(!item?.url)e.preventDefault();
      chooseSuggestion(item);
    });
    searchForm?.addEventListener("submit",e=>{
      e.preventDefault();
      hideSuggestions();
      filterSearch();
      panels.forEach(panel=>applyLimit(panel));
      root.scrollIntoView({behavior:"smooth",block:"start"});
    });
    document.addEventListener("click",e=>{
      if(!searchForm?.contains(e.target))hideSuggestions();
    });
    window.addEventListener("resize",()=>panels.forEach(panel=>applyLimit(panel)));
    const initialQuery=new URLSearchParams(location.search).get("q");
    if(search&&initialQuery&&!search.value){
      search.value=initialQuery;
      panels.forEach(panel=>panel.classList.add("is-expanded"));
    }
    setTopic(root.dataset.initialTopic||topics[0]?.dataset.faqTopic);
  });

  document.addEventListener("keydown",e=>{
    if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){
      const search=document.querySelector("[data-faq-search]");
      if(search){
        e.preventDefault();
        search.focus();
      }
    }
  });
}
function initCollectionPage(){
  document.querySelectorAll("[data-collection-page]").forEach(root=>{
    const filters=root.querySelector("[data-collection-filters]");
    const openButtons=root.querySelectorAll("[data-collection-filter-open]");
    const closeButton=root.querySelector("[data-collection-filter-close]");
    const bundleToggles=root.querySelectorAll("[data-collection-bundle-toggle]");
    const setFilters=open=>{
      if(!open&&filters?.contains(document.activeElement))document.activeElement.blur();
      root.classList.toggle("is-filters-open",open);
      filters?.setAttribute("aria-hidden",String(!open));
      filters?.toggleAttribute("inert",!open&&window.matchMedia("(max-width: 1000px)").matches);
      openButtons.forEach(button=>button.setAttribute("aria-expanded",String(open)));
      document.body.classList.toggle("ltv-collection-filter-open",open);
    };
    openButtons.forEach(button=>button.addEventListener("click",()=>setFilters(true)));
    closeButton?.addEventListener("click",()=>setFilters(false));
    filters?.addEventListener("click",e=>{if(e.target.matches("a"))setFilters(false)});
    document.addEventListener("keydown",e=>{if(e.key==="Escape")setFilters(false)});
    if(filters&&!window.matchMedia("(max-width: 1000px)").matches){
      filters.removeAttribute("aria-hidden");
      filters.removeAttribute("inert");
    }

    const setBundleVisible=visible=>{
      root.classList.toggle("is-bundle-visible",visible);
      bundleToggles.forEach(toggle=>{toggle.checked=visible});
    };
    if(bundleToggles.length){
      setBundleVisible([...bundleToggles].some(toggle=>toggle.checked));
      bundleToggles.forEach(toggle=>toggle.addEventListener("change",()=>setBundleVisible(toggle.checked)));
    }

    const collectionFilterForm=root.querySelector("[data-collection-filter-form]");
    const collectionApplyButton=collectionFilterForm?.querySelector(".ltv-collection-filter-apply");
    const normalizeSmartFilter=value=>String(value||"").toLowerCase().trim().replace(/&/g," and ").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");
    const smartGroups=[
      {name:"ltv_artisan",cardKey:"artisanKey",fallbackKey:"artisan",selector:"[data-smart-artisan-filter]",storageKey:`ltv_artisan_filter:${location.pathname}`},
      {name:"ltv_city",cardKey:"cityKey",fallbackKey:"city",selector:"[data-smart-city-filter]",storageKey:`ltv_city_filter:${location.pathname}`}
    ].map(group=>{
      const saved=(()=>{try{return JSON.parse(sessionStorage.getItem(group.storageKey)||"[]")}catch(e){return[]}})();
      const params=new Set([...new URLSearchParams(location.search).getAll(group.name),...saved].map(normalizeSmartFilter).filter(Boolean));
      return {...group,inputs:[...root.querySelectorAll(group.selector)],params};
    }).filter(group=>group.inputs.length);
    const selectedSmartFilters=()=>smartGroups.map(group=>({
      ...group,
      selected:normalizeSmartFilter(group.inputs.find(input=>input.checked)?.value)
    })).filter(group=>group.selected);
    const applySmartCollectionFilters=()=>{
      const selectedGroups=selectedSmartFilters();
      let visible=0;
      root.querySelectorAll("[data-product-card]").forEach(card=>{
        if(!card.closest(".ltv-masonry"))return;
        const show=selectedGroups.every(group=>group.selected===normalizeSmartFilter(card.dataset[group.cardKey]||card.dataset[group.fallbackKey]));
        card.classList.toggle("is-smart-filter-hidden",!show);
        if(show)card.style.removeProperty("display");
        else card.style.setProperty("display","none","important");
        if(show)visible+=1;
      });
      root.classList.toggle("is-smart-filter-empty",selectedGroups.length>0&&visible===0);
    };
    const hasNativeFilterChanges=()=>{
      if(!collectionFilterForm)return false;
      return [...collectionFilterForm.elements].some(field=>{
        if(!field.name||field.name==="ltv_artisan"||field.name==="ltv_city"||field.name==="sort_by")return false;
        if(field.type==="hidden")return !field.disabled&&field.value;
        if(field.type==="checkbox"||field.type==="radio")return field.checked;
        return field.value;
      });
    };
    const syncSmartFilterUrl=()=>{
      const url=new URL(location.href);
      smartGroups.forEach(group=>{
        url.searchParams.delete(group.name);
        const selected=group.inputs.filter(input=>input.checked).map(input=>normalizeSmartFilter(input.value)).filter(Boolean).slice(0,1);
        selected.forEach(value=>url.searchParams.append(group.name,value));
        try{
          if(selected.length)sessionStorage.setItem(group.storageKey,JSON.stringify(selected));
          else sessionStorage.removeItem(group.storageKey);
        }catch(e){}
      });
      history.replaceState({}, "", url.toString());
    };
    if(smartGroups.length){
      smartGroups.forEach(group=>{
        let restored=false;
        group.inputs.forEach(input=>{
          const shouldRestore=!restored&&group.params.has(normalizeSmartFilter(input.value));
          input.checked=shouldRestore;
          if(shouldRestore)restored=true;
          input.closest(".ltv-search-filter-option")?.classList.toggle("is-active",input.checked);
          input.addEventListener("change",()=>{
            if(input.checked){
              group.inputs.forEach(other=>{
                if(other!==input){
                  other.checked=false;
                  other.closest(".ltv-search-filter-option")?.classList.remove("is-active");
                }
              });
            }
            input.closest(".ltv-search-filter-option")?.classList.toggle("is-active",input.checked);
          });
        });
      });
      applySmartCollectionFilters();
      collectionApplyButton?.addEventListener("click",event=>{
        syncSmartFilterUrl();
        applySmartCollectionFilters();
        if(hasNativeFilterChanges())return;
        event.preventDefault();
        setFilters(false);
      });
      collectionFilterForm?.addEventListener("submit",event=>{
        syncSmartFilterUrl();
        if(hasNativeFilterChanges())return;
        event.preventDefault();
        applySmartCollectionFilters();
        setFilters(false);
      });
      filters?.querySelector(".ltv-collection-active-filters a")?.addEventListener("click",()=>{
        smartGroups.forEach(group=>{try{sessionStorage.removeItem(group.storageKey)}catch(e){}});
      });
    }

    root.querySelectorAll("[data-price-range]").forEach(range=>{
      const minRange=range.querySelector("[data-price-min-range]");
      const maxRange=range.querySelector("[data-price-max-range]");
      const minInput=range.querySelector("[data-price-min-input]");
      const maxInput=range.querySelector("[data-price-max-input]");
      const minLabel=range.querySelector("[data-price-min-label]");
      const maxLabel=range.querySelector("[data-price-max-label]");
      if(!minRange||!maxRange||!minInput||!maxInput)return;
      const floor=Number(range.dataset.min||0);
      const ceiling=Number(range.dataset.max||maxRange.max||0);
      const money=value=>"Rs. "+Number(value||0).toLocaleString("en-IN",{maximumFractionDigits:0});
      const sync=changed=>{
        let minValue=Number(minRange.value||floor);
        let maxValue=Number(maxRange.value||ceiling);
        if(minValue>maxValue){
          if(changed===minRange)maxValue=minValue;
          else minValue=maxValue;
        }
        minRange.value=String(minValue);
        maxRange.value=String(maxValue);
        minInput.value=minValue>floor?String(minValue):"";
        maxInput.value=maxValue<ceiling?String(maxValue):"";
        minInput.disabled=minValue<=floor;
        maxInput.disabled=maxValue>=ceiling;
        if(minLabel)minLabel.textContent=money(minValue);
        if(maxLabel)maxLabel.textContent=money(maxValue);
        const span=Math.max(1,ceiling-floor);
        range.style.setProperty("--price-min",`${((minValue-floor)/span)*100}%`);
        range.style.setProperty("--price-max",`${((maxValue-floor)/span)*100}%`);
      };
      minRange.addEventListener("input",()=>sync(minRange));
      maxRange.addEventListener("input",()=>sync(maxRange));
      sync();
    });

    root.querySelectorAll(".ltv-filter-group").forEach(group=>{
      const options=[...group.querySelectorAll(".ltv-check")];
      if(options.length<=5)return;
      group.classList.add("is-collapsed");
      options.slice(5).forEach(option=>option.hidden=true);
      const button=document.createElement("button");
      button.type="button";
      button.className="ltv-filter-see-more";
      button.textContent=`See ${options.length-5} more`;
      group.appendChild(button);
      button.addEventListener("click",()=>{
        const expanded=group.classList.toggle("is-expanded");
        group.classList.toggle("is-collapsed",!expanded);
        options.slice(5).forEach(option=>option.hidden=!expanded);
        button.textContent=expanded?"Show less":`See ${options.length-5} more`;
      });
    });
  });
}
function initOrderTracking(){
  const root=document.querySelector("[data-order-tracking]");
  if(!root)return;
  const endpoint=root.dataset.endpoint;
  const demo=root.dataset.demo==="true";
  const content=root.querySelector("[data-track-content]");
  const loading=root.querySelector("[data-track-loading]");
  const empty=root.querySelector("[data-track-empty]");
  const emptyHeading=root.querySelector("[data-track-empty-heading]");
  const emptyText=root.querySelector("[data-track-empty-text]");
  const params=new URLSearchParams(location.search);
  const order=params.get("order")||root.dataset.order||"";
  if(order)root.dataset.order=order;
  const setPanel=(state,heading,text)=>{
    if(content)content.hidden=state!=="content";
    if(loading)loading.hidden=state!=="loading";
    if(empty)empty.hidden=state!=="empty";
    if(state==="empty"){
      if(heading&&emptyHeading)emptyHeading.textContent=heading;
      if(text&&emptyText)emptyText.textContent=text;
    }
  };

  const setText=(selector,value)=>{
    if(value===undefined||value===null||value==="")return;
    const el=root.querySelector(selector);
    if(el)el.textContent=value;
  };
  const forceText=(selector,value)=>{
    const el=root.querySelector(selector);
    if(el)el.textContent=value||"";
  };
  const setHref=(selector,value)=>{
    if(!value)return;
    const el=root.querySelector(selector);
    if(el)el.href=value;
  };
  const toggle=(selector,visible)=>{
    const el=root.querySelector(selector);
    if(el)el.hidden=!visible;
  };
  const setImage=(selector,value,alt,containerSelector)=>{
    if(!value)return;
    let img=root.querySelector(selector);
    if(!img&&containerSelector){
      const container=root.querySelector(containerSelector);
      if(container){
        img=document.createElement("img");
        img.setAttribute(selector.replace(/^\[/,"").replace(/\]$/,""),"");
        container.prepend(img);
        container.querySelector("[data-track-map-art]")?.remove();
      }
    }
    if(!img)return;
    img.src=value;
    if(alt)img.alt=alt;
  };
  const normalizeStatus=status=>{
    const value=String(status||"").toLowerCase();
    if(["complete","completed","done","delivered"].includes(value))return "complete";
    if(["active","current","in_transit","in-transit","shipped","out_for_delivery"].includes(value))return "active";
    return "pending";
  };
  const iconForStatus=status=>status==="complete"?"lucide:check":status==="active"?"lucide:truck":"lucide:map-pin";
  const renderTimeline=events=>{
    const timeline=root.querySelector("[data-track-timeline]");
    if(!timeline||!Array.isArray(events)||!events.length)return;
    timeline.innerHTML=events.map(event=>{
      const status=normalizeStatus(event.status);
      const icon=esc(event.icon||iconForStatus(status));
      return `<article class="ltv-track-event ${status==="complete"?"is-complete":status==="active"?"is-active":""}">
        <div class="ltv-track-event__icon"><iconify-icon icon="${icon}"></iconify-icon></div>
        <div>
          <h3>${esc(event.title||"")}</h3>
          <p>${esc(event.text||"")}</p>
          ${event.notice?`<div class="ltv-track-notice"><iconify-icon icon="lucide:info"></iconify-icon>${esc(event.notice)}</div>`:""}
        </div>
        <time>${esc(event.date||"")}</time>
      </article>`;
    }).join("");
  };
  const renderCare=items=>{
    const list=root.querySelector("[data-track-care-list]");
    if(!list||!Array.isArray(items)||!items.length)return;
    list.innerHTML=items.map(item=>`<article>
      <iconify-icon icon="${esc(item.icon||"lucide:sparkles")}"></iconify-icon>
      <div>
        <h3>${esc(item.title||"")}</h3>
        <p>${esc(item.text||item.description||"")}</p>
      </div>
    </article>`).join("");
  };
  const renderRelated=items=>{
    const list=root.querySelector("[data-track-related-list]");
    if(!list||!Array.isArray(items)||!items.length)return;
    list.innerHTML=items.map(item=>{
      const image=item.image||item.image_url||"";
      const body=`${image?`<img src="${esc(image)}" alt="${esc(item.title||"Related product")}">`:""}
        <h3>${esc(item.title||"")}</h3>
        <p>${esc(item.price||"")}</p>`;
      return item.url?`<article><a href="${esc(item.url)}">${body}</a></article>`:`<article>${body}</article>`;
    }).join("");
  };
  const addressText=address=>{
    if(!address)return "";
    if(typeof address==="string")return address;
    const lines=Array.isArray(address.lines)?address.lines:[address.line1,address.line2].filter(Boolean);
    return [address.name,...lines,address.city,address.province||address.state,address.zip||address.postal_code,address.country].filter(Boolean).join("\n");
  };
  const hasRealTrackingData=data=>{
    if(!data||data.error||data.not_found)return false;
    return Boolean(data.order_number||data.order_name||data.name||data.timeline?.length||data.events?.length||data.shipment||data.fulfillment||data.fulfillments?.length);
  };
  const hasObjectData=obj=>obj&&Object.values(obj).some(value=>Array.isArray(value)?value.length:Boolean(value));

  setText("[data-track-order-label]",order);
  if(demo){
    setPanel("content");
    return;
  }
  if(!order){
    setPanel("empty",root.dataset.emptyHeading,root.dataset.emptyText);
    return;
  }
  if(!endpoint){
    setPanel("empty",root.dataset.apiMissingHeading,root.dataset.apiMissingText);
    return;
  }
  setPanel("loading");

  try{
    const url=new URL(endpoint,location.origin);
    if(order&&!url.searchParams.has("order"))url.searchParams.set("order",order);
    fetch(url.toString(),{headers:{"Accept":"application/json"}})
      .then(response=>response.ok?response.json():null)
      .then(data=>{
        if(!hasRealTrackingData(data)){
          setPanel("empty",root.dataset.notFoundHeading,root.dataset.notFoundText);
          return;
        }
        const shipment=data.shipment||data.fulfillment||data.fulfillments?.[0]||{};
        const product=data.product||data.item||data.line_item||data.line_items?.[0]||{};
        const maker=data.maker||data.artisan||product.maker||product.artisan||{};
        const address=data.address||data.delivery_address||data.shipping_address||data.shippingAddress;
        const events=data.timeline||data.events||shipment.timeline||shipment.events||shipment.checkpoints;
        const careItems=data.care?.items||data.care_items;
        const relatedItems=data.related?.items||data.related_products||data.recommendations;
        const productVisible=hasObjectData(product);
        const makerVisible=hasObjectData(maker);
        const eventsVisible=Boolean(events?.length);
        forceText("[data-track-order-label]",data.order_number||data.order_name||data.name||order);
        forceText("[data-track-heading]",data.heading||"Your order journey is being updated.");
        forceText("[data-track-delivery]",data.estimated_delivery||data.delivery_date||shipment.estimated_delivery||shipment.estimated_delivery_at||"Awaiting carrier update");
        setText(".ltv-track-heading-row h2",data.journey_heading);
        forceText("[data-track-origin]",data.origin||shipment.origin||shipment.origin_location||"Origin pending");
        setText("[data-track-carrier]",data.carrier||data.carrier_label||shipment.carrier||shipment.tracking_company);
        forceText("[data-track-destination]",data.destination||shipment.destination||shipment.destination_location||"Destination pending");
        toggle("[data-track-product]",productVisible);
        forceText("[data-track-product-title]",product.title);
        forceText("[data-track-product-meta]",product.meta||product.description);
        toggle("[data-track-maker]",makerVisible);
        forceText("[data-track-maker-name]",maker.name);
        forceText("[data-track-maker-location]",maker.location);
        forceText("[data-track-maker-message]",maker.message);
        toggle("[data-track-care]",Boolean(data.care||careItems?.length));
        forceText("[data-track-care-heading]",data.care?.heading||"Care & Rituals");
        forceText("[data-track-care-text]",data.care?.text||data.care?.description);
        setText("[data-track-address-heading]",address?.heading);
        toggle("[data-track-address]",Boolean(address));
        forceText("[data-track-address-text]",addressText(address));
        setText("[data-track-related-heading]",data.related_heading||data.related?.heading);
        toggle("[data-track-related]",Boolean(relatedItems?.length));
        setHref(".ltv-track-heading-row a",data.receipt_url||data.order_status_url||data.status_url);
        toggle(".ltv-track-heading-row a",Boolean(data.receipt_url||data.order_status_url||data.status_url));
        toggle(".ltv-track-actions .ltv-track-primary",Boolean(data.more_url||maker.url));
        setHref(".ltv-track-actions .ltv-track-primary",data.more_url||maker.url);
        setHref(".ltv-track-actions .ltv-track-secondary",data.support_url);
        toggle(".ltv-track-mobile-actions .ltv-track-primary",Boolean(data.details_url||data.order_status_url||data.status_url||shipment.tracking_url||data.more_url));
        setHref(".ltv-track-mobile-actions .ltv-track-primary",data.details_url||data.order_status_url||data.status_url||shipment.tracking_url||data.more_url);
        setHref(".ltv-track-mobile-actions .ltv-track-secondary",data.support_url);
        setHref("[data-track-maker-video]",maker.video_url);
        setImage("[data-track-map-img]",data.map_image||data.map?.image,data.journey_heading,".ltv-track-map");
        setImage("[data-track-product-img]",product.image||product.image_url,product.title);
        setImage("[data-track-maker-img]",maker.image||maker.image_url,maker.name);
        toggle(".ltv-track-timeline-card",productVisible||eventsVisible);
        toggle("[data-track-timeline]",eventsVisible);
        renderTimeline(events);
        renderCare(careItems);
        renderRelated(relatedItems);
        setPanel("content");
      })
      .catch(error=>{
        console.warn("Order tracking endpoint failed",error);
        setPanel("empty",root.dataset.notFoundHeading,root.dataset.notFoundText);
      });
  }catch(error){
    console.warn("Invalid order tracking endpoint",error);
    setPanel("empty",root.dataset.apiMissingHeading,root.dataset.apiMissingText);
  }
}
function initCitiesFilters(){
  const filters=document.querySelector("[data-city-filters]");
  const cards=[...document.querySelectorAll("[data-city-card]")];
  if(!filters||!cards.length)return;
  const countCards=[...document.querySelectorAll("[data-city-grid] [data-city-card]")];
  const state={region:"all",craft:"all"};
  const countEl=document.querySelector("[data-city-count]");
  const emptyEl=document.querySelector("[data-city-filter-empty]");
  const apply=()=>{
    let visible=0;
    let visibleInGrid=0;
    cards.forEach(card=>{
      const regionMatch=state.region==="all"||card.dataset.region===state.region;
      const craftMatch=state.craft==="all"||(card.dataset.crafts||"").split(/\s+/).includes(state.craft);
      const show=regionMatch&&craftMatch;
      card.hidden=!show;
      if(show)visible+=1;
    });
    countCards.forEach(card=>{if(!card.hidden)visibleInGrid+=1});
    if(countEl)countEl.textContent=`Showing ${visibleInGrid} ${visibleInGrid===1?"destination":"destinations"}`;
    if(emptyEl)emptyEl.hidden=visibleInGrid>0;
  };
  filters.addEventListener("click",event=>{
    const button=event.target.closest("[data-city-filter]");
    if(!button)return;
    const type=button.dataset.cityFilter;
    state[type]=button.dataset.cityValue||"all";
    filters.querySelectorAll(`[data-city-filter="${type}"]`).forEach(item=>item.classList.toggle("is-active",item===button));
    apply();
  });
  apply();
}
function initCityArticleMap(){
  document.querySelectorAll("[data-city-map]").forEach(root=>{
    const places=[...root.querySelectorAll("[data-city-map-place]")];
    const image=root.querySelector("[data-city-map-image]");
    const mobileTitle=root.querySelector("[data-city-map-mobile-title]");
    const mobileText=root.querySelector("[data-city-map-mobile-text]");
    const next=root.querySelector("[data-city-map-next]");
    if(!places.length)return;
    const parsedImages=(root.dataset.mapImages||"").match(/https?:\/\/[^,\s"']+/g)||[];
    places.forEach((place,index)=>{
      if(parsedImages[index])place.dataset.mapImage=parsedImages[index].trim();
    });
    let activeIndex=Math.max(0,places.findIndex(place=>place.classList.contains("is-active")));
    places.forEach(place=>{
      const src=(place.dataset.mapImage||"").trim();
      if(src){
        const preload=new Image();
        preload.src=src;
      }
    });
    const activate=(index,updateHash=false)=>{
      const place=places[index];
      if(!place)return;
      activeIndex=index;
      places.forEach(item=>item.classList.toggle("is-active",item===place));
      const nextImage=(place.dataset.mapImage||"").trim();
      if(image&&nextImage&&image.src!==nextImage){
        image.src=nextImage;
        image.alt=place.dataset.mapTitle||image.alt;
      }
      if(mobileTitle)mobileTitle.textContent=place.dataset.mapTitle||"";
      if(mobileText)mobileText.textContent=place.dataset.mapText||"";
      if(updateHash&&place.getAttribute("href")&&place.getAttribute("href")!=="#"){
        window.location.href=place.href;
      }
    };
    places.forEach((place,index)=>{
      place.addEventListener("click",event=>{
        event.preventDefault();
        activate(index);
      });
    });
    next?.addEventListener("click",()=>activate((activeIndex+1)%places.length));
    activate(activeIndex);
  });
}
window.addEventListener("storage",event=>{if(event.key&&event.key.startsWith("ltv_"))updateStickyBar()});
document.addEventListener("DOMContentLoaded",()=>{
  bindCommon();
  initGrids();
  syncWishlistState();
  initProduct();
  initStoriesPage();
  initCart();
  initWishlist();
  initGift();
  initPreferences();
  initSiteSearchSuggestions();
  initSearch();
  initFaq();
  initCollectionPage();
  initOrderTracking();
  initCitiesFilters();
  initCityArticleMap();
  updateStickyBar();

  const initDeferredMedia=()=>{
    initVideoPreviews();
    initInlineVideos();
    initHomeStoryAccordion();
  };
  if("requestIdleCallback" in window){
    window.requestIdleCallback(initDeferredMedia,{timeout:1200});
  }else{
    window.setTimeout(initDeferredMedia,300);
  }
});

