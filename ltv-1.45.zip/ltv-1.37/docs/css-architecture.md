# CSS Architecture

The theme CSS is loaded through `snippets/ltv-css-assets.liquid`.

Load order matters:

1. `localtevocal.css` - base tokens, shared layout, header/footer foundations.
2. Page CSS loaded only when needed, for example `ltv-order-tracking.css`.
3. `ltv-theme-mid.css` - small shared styles that originally sat between page blocks.
4. `ltv-faq.css` - legacy FAQ layer. This still contains some global primitives from the old monolith, so it currently loads globally.
5. `ltv-theme-overrides.css` - final legacy overrides and page refinements.
6. `ltv-product-cards.css` - final product-card and collection-card overrides.

When adding new CSS:

- Put reusable primitives in `localtevocal.css`.
- Put template-specific rules in a named file like `ltv-cart.css` or `ltv-search.css`.
- Add conditional loading in `snippets/ltv-css-assets.liquid`.
- Keep final overrides scoped by page/template class where possible.
- Avoid adding broad `!important` rules unless a legacy cascade conflict requires it.
