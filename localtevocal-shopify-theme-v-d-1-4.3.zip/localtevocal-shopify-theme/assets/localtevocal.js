const LTV={products:[
{id:"azure-heritage-vase",title:"The Azure Heritage Vase",price:145,compare:175,image:"https://images.unsplash.com/photo-1546454272-5914d75c01e9?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1546454272-5914d75c01e9?w=800&h=800&fit=crop","https://images.unsplash.com/photo-1716222324740-0770c29282b9?w=800&h=800&fit=crop","https://images.unsplash.com/photo-1715845883469-54c2486a0a82?w=800&h=800&fit=crop"],artisan:"Priya Sharma",city:"Khurja",craft:"Blue Pottery",rating:4.5,reviews:24,bundle:true,description:"A masterpiece of Khurja's blue pottery tradition, this vase features hand-painted cobalt patterns inspired by Mughal architecture.",materials:"Quartz, raw glaze, cobalt oxide, natural minerals",dimensions:"12 H x 6 W x 6 D"},
{id:"crimson-raku-bowl",title:"Crimson Raku Bowl Set",price:89,image:"https://images.unsplash.com/photo-1615640325967-af4cfa4c0c6a?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1615640325967-af4cfa4c0c6a?w=800&h=800&fit=crop"],artisan:"Priya Sharma",city:"Khurja",craft:"Blue Pottery",rating:4.8,reviews:31,bundle:true,description:"A set of four hand-glazed bowls with a stunning crimson raku finish, perfect for serving or display."},
{id:"indigo-block-scarf",title:"Indigo Block Print Scarf",price:65,compare:80,image:"https://images.unsplash.com/photo-1608793733118-ee3f16002251?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1608793733118-ee3f16002251?w=800&h=800&fit=crop"],artisan:"Rajan Mehta",city:"Jaipur",craft:"Block Printing",rating:4.3,reviews:18,bundle:true,description:"Hand-stamped with traditional wooden blocks using natural indigo dye on pure cotton."},
{id:"varanasi-silk-stole",title:"Varanasi Silk Brocade Stole",price:195,compare:240,image:"https://images.pexels.com/photos/18363710/pexels-photo-18363710.jpeg?w=600&h=600&fit=crop",images:["https://images.pexels.com/photos/18363710/pexels-photo-18363710.jpeg?w=800&h=800&fit=crop"],artisan:"Lakshmi Devi",city:"Varanasi",craft:"Silk Weaving",rating:4.7,reviews:42,bundle:false,description:"Luxurious hand-woven silk stole with intricate gold brocade motifs from the looms of Varanasi."},
{id:"terracotta-planter",title:"Terracotta Garden Planter",price:78,image:"https://images.unsplash.com/photo-1531452454767-de8511addfdf?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1531452454767-de8511addfdf?w=800&h=800&fit=crop"],artisan:"Priya Sharma",city:"Khurja",craft:"Blue Pottery",rating:4.2,reviews:15,bundle:true,description:"A beautifully handcrafted terracotta planter with traditional Khurja blue glaze accents."},
{id:"rosewood-jewelry-box",title:"Hand-carved Rosewood Box",price:120,compare:150,image:"https://images.unsplash.com/photo-1680777019951-9cc1abaa0471?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1680777019951-9cc1abaa0471?w=800&h=800&fit=crop"],artisan:"Amir Khan",city:"Srinagar",craft:"Wood Carving",rating:4.6,reviews:27,bundle:true,description:"Intricately carved rosewood jewelry box featuring traditional Kashmiri motifs."},
{id:"brass-diya-set",title:"Brass Diya Lamp Set",price:55,image:"https://images.unsplash.com/photo-1552590854-5b55d5425066?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1552590854-5b55d5425066?w=800&h=800&fit=crop"],artisan:"Amir Khan",city:"Moradabad",craft:"Brassware",rating:4.4,reviews:19,bundle:true,description:"Set of five hand-cast brass diya lamps with intricate engraving, perfect for festivals."},
{id:"pashmina-shawl",title:"Kashmir Pashmina Shawl",price:250,compare:320,image:"https://images.unsplash.com/photo-1598616068517-c75ad397a436?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1598616068517-c75ad397a436?w=800&h=800&fit=crop"],artisan:"Fatima Bi",city:"Srinagar",craft:"Silk Weaving",rating:4.9,reviews:56,bundle:false,description:"Luxuriously soft hand-woven pashmina shawl with traditional Kashmiri sozni embroidery."},
{id:"blue-pottery-tea-set",title:"Blue Pottery Tea Set",price:110,image:"https://images.unsplash.com/photo-1716222324740-0770c29282b9?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1716222324740-0770c29282b9?w=800&h=800&fit=crop"],artisan:"Rajan Mehta",city:"Jaipur",craft:"Blue Pottery",rating:4.5,reviews:33,bundle:true,description:"A charming tea set in traditional Jaipur blue pottery style with floral motifs."},
{id:"silver-filigree-earrings",title:"Silver Filigree Earrings",price:85,compare:100,image:"https://images.unsplash.com/photo-1722510825242-0d8f2064c2e2?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1722510825242-0d8f2064c2e2?w=800&h=800&fit=crop"],artisan:"Meera Devi",city:"Moradabad",craft:"Filigree",rating:4.7,reviews:38,bundle:true,description:"Delicate silver filigree earrings featuring traditional Odissi motifs."},
{id:"bidri-vase",title:"Bidri Art Vase",price:135,compare:165,image:"https://images.unsplash.com/photo-1715845883469-54c2486a0a82?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1715845883469-54c2486a0a82?w=800&h=800&fit=crop"],artisan:"Fatima Bi",city:"Bidar",craft:"Bidri Work",rating:4.3,reviews:12,bundle:false,description:"Stunning Bidri art vase with pure silver inlay on oxidized zinc alloy."},
{id:"kantha-cushion",title:"Kantha Embroidered Cushion",price:45,image:"https://images.pexels.com/photos/15131488/pexels-photo-15131488.jpeg?w=600&h=600&fit=crop",images:["https://images.pexels.com/photos/15131488/pexels-photo-15131488.jpeg?w=800&h=800&fit=crop"],artisan:"Meera Devi",city:"Jaipur",craft:"Kantha Embroidery",rating:4.6,reviews:21,bundle:true,description:"Vibrant cushion cover featuring traditional Kantha running stitch embroidery."}
],cities:[["khurja","Khurja","Blue Pottery","The Ceramic City","https://images.unsplash.com/photo-1630042924261-7453b1957f5c?w=800&h=500&fit=crop"],["jaipur","Jaipur","Block Printing & Blue Pottery","The Pink City of Crafts","https://images.unsplash.com/photo-1607160913542-6234aae47ec5?w=800&h=500&fit=crop"],["varanasi","Varanasi","Silk Weaving","The City of Weavers","https://images.unsplash.com/photo-1561028341-d1fbd27889b2?w=800&h=500&fit=crop"],["moradabad","Moradabad","Brassware","Brass City of India","https://images.unsplash.com/photo-1552590854-5b55d5425066?w=800&h=500&fit=crop"],["srinagar","Srinagar","Wood Carving & Pashmina","Paradise of Craftsmanship","https://images.unsplash.com/photo-1511729530272-7198cdce7b8a?w=800&h=500&fit=crop"],["bidar","Bidar","Bidri Work","City of Silver & Shadow","https://images.pexels.com/photos/19035171/pexels-photo-19035171.jpeg?w=800&h=500&fit=crop"]]};
const store={
  get(k){
    try{return JSON.parse(localStorage.getItem("ltv_"+k)||"[]")}catch(e){return[]}
  },
  set(k,v){
    localStorage.setItem("ltv_"+k,JSON.stringify(v));
    this.refresh();
  },
  add(k,item){
    const a=this.get(k);
    const i=a.findIndex(x=>x.id===item.id);
    if(i>-1){
      a[i].qty=(a[i].qty||1)+1;
    } else {
      a.push({...item,qty:1});
    }
    this.set(k,a);
  },
  remove(k,id){
    this.set(k,this.get(k).filter(x=>x.id!==id));
  },
  refresh(){
    this.refreshWishlist();
    this.refreshGift();
    refreshCartCount();
  },
  refreshWishlist(){
    document.querySelectorAll("[data-wishlist-count]").forEach(e=>{const n=this.get("wishlist").length;e.textContent=n?n:""});
  },
  refreshGift(){
    document.querySelectorAll("[data-gift-count]").forEach(e=>{const n=this.get("gift").length;e.textContent=n?n:""});
  }
};
function productCard(p){const variantId=p.variantId||"";const url=p.url||`/products/${p.id}`;const canAdd=/^\d+$/.test(String(variantId));return `<article class="ltv-product-card" data-product-card data-id="${p.id}" data-title="${p.title}" data-price="${p.price}" data-image="${p.image}" data-url="${url}" ${canAdd?`data-variant-id="${variantId}"`:''} data-artisan="${p.artisan||''}" data-city="${p.city||''}" data-story="${p.description||''}"><a class="ltv-product-card__image" href="${url}"><img src="${p.image}" width="700" height="875" alt="${p.title}" loading="lazy" decoding="async">${p.bundle?'<span class="ltv-badge"><iconify-icon icon="lucide:package"></iconify-icon>Bundle Ready</span>':''}<div class="ltv-card-actions"><button type="button" class="ltv-circle-btn" data-wishlist-add aria-label="Add to wishlist"><iconify-icon icon="lucide:heart"></iconify-icon></button>${canAdd?`<button type="button" class="ltv-circle-btn ltv-circle-btn--terra" data-local-cart-add data-variant-id="${variantId}" aria-label="Add to cart"><iconify-icon icon="lucide:shopping-bag"></iconify-icon></button>`:''}</div></a><div class="ltv-product-card__body"><div class="ltv-product-card__row"><h3><a href="${url}">${p.title}</a></h3><strong>₹${p.price}</strong></div><p><iconify-icon icon="lucide:user"></iconify-icon>${p.artisan}<span></span><iconify-icon icon="lucide:map-pin"></iconify-icon>${p.city}</p></div></article>`}

async function refreshCartCount(){
  try{
    const response=await fetch('/cart.js');
    if(!response.ok)return;
    const cart=await response.json();
    document.querySelectorAll('[data-cart-count]').forEach(e=>{e.textContent=cart.item_count?cart.item_count:''});
  }catch(e){console.warn('Unable to refresh cart count',e)}
}

async function addToCartAjax(variantId,quantity=1){
  if(!variantId)return false;
  try{
    const response=await fetch('/cart/add.js',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:variantId,quantity})});
    if(response.ok){
      refreshCartCount();
      return true;
    }
  }catch(e){console.warn('Add to cart failed',e)}
  return false;
}

function bindCommon(){
  store.refresh();
  const megaTriggers=document.querySelectorAll('[data-mega-trigger]');
  const closeMega=()=>{
    document.querySelectorAll('[data-mega]').forEach(m=>m.classList.remove('is-open'));
    megaTriggers.forEach(trigger=>trigger.setAttribute('aria-expanded','false'));
  };
  const openMega=name=>{
    document.querySelectorAll('[data-mega]').forEach(m=>m.classList.toggle('is-open',m.dataset.mega===name));
    megaTriggers.forEach(trigger=>trigger.setAttribute('aria-expanded',String(trigger.dataset.megaTrigger===name)));
  };
  document.querySelectorAll('[data-mega-trigger]').forEach(a=>{
    a.addEventListener('mouseenter',()=>openMega(a.dataset.megaTrigger));
    a.addEventListener('focus',()=>openMega(a.dataset.megaTrigger));
    a.addEventListener('click',e=>{
      const menu=document.querySelector(`[data-mega="${a.dataset.megaTrigger}"]`);
      if(!menu)return;
      const isCoarse=window.matchMedia('(hover: none), (pointer: coarse)').matches;
      if(isCoarse||!menu.classList.contains('is-open')){
        e.preventDefault();
        menu.classList.contains('is-open')?closeMega():openMega(a.dataset.megaTrigger);
      }
    });
  });
  document.querySelector('[data-ltv-header]')?.addEventListener('mouseleave',closeMega);
  document.addEventListener('click',e=>{if(!e.target.closest('[data-ltv-header]'))closeMega()});
  const mobileMenu=document.querySelector('[data-mobile-menu]');
  const mobileOpen=document.querySelector('[data-mobile-open]');
  const setMobileOpen=open=>{
    if(!mobileMenu)return;
    mobileMenu.classList.toggle('is-open',open);
    mobileMenu.setAttribute('aria-hidden',String(!open));
    mobileOpen?.setAttribute('aria-expanded',String(open));
    document.body.classList.toggle('ltv-menu-open',open);
  };
  mobileOpen?.addEventListener('click',()=>setMobileOpen(true));
  document.querySelector('[data-mobile-close]')?.addEventListener('click',()=>setMobileOpen(false));
  mobileMenu?.addEventListener('click',e=>{if(e.target.matches('a'))setMobileOpen(false)});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeMega();setMobileOpen(false)}});
  document.body.addEventListener('click',async e=>{
    const cartButton=e.target.closest('[data-local-cart-add]');
    if(cartButton){
      const form=cartButton.closest('form');
      const variantId=cartButton.dataset.variantId||form?.querySelector('[name="id"]')?.value;
      if(!/^\d+$/.test(String(variantId||''))) return;
      e.preventDefault();
      const added=await addToCartAjax(variantId,Number(cartButton.dataset.quantity||1));
      if(!added&&form) form.submit();
      return;
    }
    const wishlistButton=e.target.closest('[data-wishlist-add]');
    if(wishlistButton){
      e.preventDefault();
      const card=wishlistButton.closest('[data-product-card]');
      if(!card)return;
      store.add('wishlist',{id:card.dataset.id,title:card.dataset.title,price:card.dataset.price,image:card.dataset.image,url:card.dataset.url,variantId:card.dataset.variantId,artisan:card.dataset.artisan,city:card.dataset.city,story:card.dataset.story});
      return;
    }
    const giftButton=e.target.closest('[data-gift-add]');
    if(giftButton){
      e.preventDefault();
      const card=giftButton.closest('[data-product-card]');
      const rawPrice=card?.dataset.price||"0";
      const price=Number(String(rawPrice).replace(/[^0-9.]/g,""))||0;
      const item=card?{id:card.dataset.id,title:card.dataset.title,price,image:card.dataset.image,url:card.dataset.url,variantId:card.dataset.variantId,artisan:card.dataset.artisan,city:card.dataset.city,story:card.dataset.story} : {id:'gift-item',title:'Artisan Gift',price:0,image:''};
      store.add('gift',item);
      notify("Added to gift builder");
      return;
    }
  });
  document.body.addEventListener('keydown',e=>{
    const giftButton=e.target.closest?.('[data-gift-add]');
    if(!giftButton || (e.key!=='Enter'&&e.key!==' ')) return;
    e.preventDefault();
    giftButton.click();
  });
}
function initGrids(){document.querySelectorAll("[data-products-grid]").forEach(el=>{if(!el.innerHTML.trim()){let arr=LTV.products;if(el.dataset.limit)arr=arr.slice(0,+el.dataset.limit);el.innerHTML=arr.map(productCard).join("")}});document.querySelectorAll("[data-cities-grid]").forEach(el=>{if(!el.innerHTML.trim()){el.innerHTML=LTV.cities.slice(0,el.dataset.limit||99).map(c=>`<a href="/pages/cities#${c[0]}" class="ltv-city-card"><img src="${c[4]}" width="800" height="500" alt="${c[1]}" loading="lazy" decoding="async"><h3>${c[1]}</h3><p>Famed for: ${c[2]}</p></a>`).join("")}})}
function initProduct(){
  const root=document.querySelector("[data-product-detail]");
  if(!root) return;
  const mainImg=root.querySelector("[data-p-main]");
  const lightbox=root.querySelector("[data-p-lightbox]");
  const lightboxImg=root.querySelector("[data-p-lightbox-img]");
  const thumbsEl=root.querySelector("[data-p-thumbs]");
  if(thumbsEl){
    thumbsEl.addEventListener("click",e=>{
      const b=e.target.closest("button");
      if(!b) return;
      if(mainImg) mainImg.src=b.dataset.thumb;
      if(lightboxImg) lightboxImg.src=b.dataset.thumb;
      thumbsEl.querySelectorAll("button").forEach(x=>x.classList.toggle("is-active",x===b));
    });
  }
  root.querySelector("[data-p-zoom-open]")?.addEventListener("click",()=>{if(lightbox) lightbox.hidden=false});
  root.querySelector("[data-p-zoom-close]")?.addEventListener("click",()=>{if(lightbox) lightbox.hidden=true});
  lightbox?.addEventListener("click",e=>{if(e.target===lightbox) lightbox.hidden=true});
  root.querySelector("[data-ltv-share]")?.addEventListener("click",async()=>{
    const title=root.dataset.title||document.title;
    const url=location.href;
    if(navigator.share){
      try{await navigator.share({title,url})}catch(e){}
      return;
    }
    try{
      await navigator.clipboard.writeText(url);
      notify("Product link copied");
    }catch(e){
      notify("Copy failed. Use your browser address bar to copy the link.");
    }
  });
  root.querySelectorAll("[data-bundle-builder]").forEach(builder=>{
    const totalEl=builder.querySelector("[data-bundle-total]");
    const savingsEl=builder.querySelector("[data-bundle-savings]");
    const base=Number(builder.dataset.basePrice||0);
    function update(){
      let total=base;
      let savings=0;
      builder.querySelectorAll("[data-bundle-item]").forEach(input=>{
        const item=input.closest(".ltv-pdp-bundle__item");
        item?.classList.toggle("is-selected",input.checked);
        if(input.checked) total+=Number(input.dataset.price||0);
        const oldText=item?.querySelector("s")?.textContent?.replace(/[^0-9.]/g,"");
        if(input.checked&&oldText) savings+=Math.max(0,Number(oldText)-Number(input.dataset.price||0));
      });
      if(totalEl) totalEl.textContent="Rs. "+total.toFixed(0);
      if(savingsEl) savingsEl.textContent=savings>0?"You save Rs. "+savings.toFixed(0):"";
    }
    builder.addEventListener("change",e=>{if(e.target.matches("[data-bundle-item]")) update()});
    update();
  });
}
function initStoriesPage(){
  const root=document;
  if(!document.querySelector("[data-stories-filter], [data-story-item], [data-stories-page]")) return;
  let active="all";
  const bundle=root.querySelector("[data-bundle-filter]");
  function apply(){
    root.querySelectorAll("[data-story-item]").forEach(item=>{
      const category=item.dataset.category;
      const bundleOk=!bundle?.checked||item.dataset.bundle==="true";
      const categoryOk=active==="all"||category===active;
      item.classList.toggle("is-hidden",!(bundleOk&&categoryOk));
    });
  }
  root.querySelectorAll("[data-story-filter]").forEach(button=>{
    button.addEventListener("click",()=>{
      active=button.dataset.storyFilter;
      root.querySelectorAll("[data-story-filter]").forEach(x=>x.classList.toggle("is-active",x===button));
      apply();
    });
  });
  bundle?.addEventListener("change",apply);
  apply();
}
function videoEmbedUrl(url){
  if(!url)return"";
  try{
    const u=new URL(url,location.origin);
    const host=u.hostname.replace(/^www\./,"");
    if(host==="youtu.be")return`https://www.youtube.com/embed/${u.pathname.slice(1)}?autoplay=1&rel=0`;
    if(host.includes("youtube.com")){
      const id=u.searchParams.get("v")||u.pathname.split("/").filter(Boolean).pop();
      return id?`https://www.youtube.com/embed/${id}?autoplay=1&rel=0`:"";
    }
    if(host.includes("vimeo.com")){
      const id=u.pathname.split("/").filter(Boolean).pop();
      return id?`https://player.vimeo.com/video/${id}?autoplay=1`:"";
    }
    return url;
  }catch(e){return url}
}
function youtubeIdFromUrl(url){
  try{
    const u=new URL(url,location.origin);
    const host=u.hostname.replace(/^www\./,"");
    if(host==="youtu.be")return u.pathname.slice(1);
    if(host.includes("youtube.com"))return u.searchParams.get("v")||u.pathname.split("/").filter(Boolean).pop();
  }catch(e){}
  return"";
}
function initVideoPreviews(){
  document.querySelectorAll("[data-video-player]").forEach(player=>{
    const url=player.dataset.videoUrl;
    if(!url||player.querySelector(".ltv-stories-video__poster"))return;
    const direct=/\.(mp4|webm|ogg)(\?.*)?$/i.test(url);
    if(direct){
      const preview=document.createElement("video");
      preview.className="ltv-stories-video__poster ltv-stories-video__poster-video";
      preview.src=url;
      preview.muted=true;
      preview.loop=true;
      preview.autoplay=true;
      preview.playsInline=true;
      preview.preload="metadata";
      preview.setAttribute("aria-hidden","true");
      player.querySelector(".ltv-stories-video__fallback")?.remove();
      player.prepend(preview);
      preview.play?.().catch(()=>{});
      return;
    }
    const id=youtubeIdFromUrl(url);
    if(id){
      const img=document.createElement("img");
      img.className="ltv-stories-video__poster";
      img.src=`https://img.youtube.com/vi/${id}/maxresdefault.jpg`;
      img.onerror=()=>{img.src=`https://img.youtube.com/vi/${id}/hqdefault.jpg`};
      img.alt=player.dataset.videoHeading||"Story video";
      player.querySelector(".ltv-stories-video__fallback")?.remove();
      player.prepend(img);
    }
  });
}
function initInlineVideos(){
  document.body.addEventListener("click",e=>{
    const trigger=e.target.closest("[data-video-play]");
    if(!trigger)return;
    const player=trigger.closest("[data-video-player]");
    if(!player||player.classList.contains("is-playing"))return;
    const url=player.dataset.videoUrl;
    if(!url){
      trigger.blur();
      return;
    }
    const embed=videoEmbedUrl(url);
    const isFile=/\.(mp4|webm|ogg)(\?.*)?$/i.test(embed);
    const el=document.createElement(isFile?"video":"iframe");
    el.className="ltv-stories-video__embed";
    if(isFile){
      el.src=embed;
      el.controls=true;
      el.autoplay=true;
      el.playsInline=true;
    }else{
      el.src=embed;
      el.allow="autoplay; encrypted-media; picture-in-picture";
      el.allowFullscreen=true;
      el.title=trigger.getAttribute("aria-label")||"Story video";
    }
    player.appendChild(el);
    player.classList.add("is-playing");
  });
}
function initCart(){
  const root=document.querySelector("[data-local-cart]");
  if(!root)return;
  root.addEventListener("click",e=>{
    const stepButton=e.target.closest("[data-cart-qty-step]");
    if(!stepButton)return;
    const qty=stepButton.closest(".ltv-cart-qty")?.querySelector('input[name="updates[]"]');
    if(!qty)return;
    const next=Math.max(Number(qty.min||0),Number(qty.value||0)+Number(stepButton.dataset.cartQtyStep||0));
    qty.value=next;
    qty.dispatchEvent(new Event("change",{bubbles:true}));
  });
}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function notify(message){
  let toast=document.querySelector("[data-ltv-toast]");
  if(!toast){
    toast=document.createElement("div");
    toast.className="ltv-toast";
    toast.dataset.ltvToast="";
    toast.setAttribute("role","status");
    toast.setAttribute("aria-live","polite");
    document.body.appendChild(toast);
  }
  toast.textContent=message;
  toast.classList.add("is-visible");
  clearTimeout(notify.timer);
  notify.timer=setTimeout(()=>toast.classList.remove("is-visible"),2600);
}
function moneyText(v){const s=String(v??'').trim();if(!s)return'';return /^(\$|₹|Rs\.|INR|USD|EUR|GBP)/i.test(s)?s:`Rs. ${s}`}
function wishlistCard(item){
  const id=esc(item.id||item.title);
  const title=esc(item.title||'Saved Product');
  const url=esc(item.url||'#');
  const image=esc(item.image||'');
  const price=esc(moneyText(item.price));
  const artisan=esc(item.artisan||'Local Artisan');
  const city=esc(item.city||'');
  const story=esc(item.story||'This saved piece carries the voice of its maker and the story of its craft.');
  const variant=item.variantId?`data-variant-id="${esc(item.variantId)}"`:'';
  const moveAction=item.variantId?`<button type="button" class="ltv-wish-move" data-wishlist-move="${id}" ${variant}>Move to Cart <iconify-icon icon="lucide:arrow-right"></iconify-icon></button>`:`<a class="ltv-wish-move" href="${url}">View Product <iconify-icon icon="lucide:arrow-right"></iconify-icon></a>`;
  return `<article class="ltv-wish-card" data-wishlist-item data-product-card data-id="${id}" data-title="${title}" data-price="${esc(item.price||'')}" data-image="${image}" data-url="${url}" ${variant}>
    <label class="ltv-wish-check"><input type="checkbox" data-wishlist-select value="${id}"><span></span></label>
    <button type="button" class="ltv-wish-remove" data-wishlist-remove="${id}" aria-label="Remove ${title}"><iconify-icon icon="lucide:trash-2"></iconify-icon></button>
    <a href="${url}"><img class="ltv-wish-card__image" src="${image}" width="520" height="650" alt="${title}" loading="lazy" decoding="async"></a>
    <div class="ltv-wish-card__body">
      <div class="ltv-wish-maker"><span class="ltv-wish-maker__avatar">${artisan.charAt(0)}</span><div><strong>${artisan}</strong><span><iconify-icon icon="lucide:map-pin"></iconify-icon>${city}</span></div></div>
      <div class="ltv-wish-title-row"><h2><a href="${url}">${title}</a></h2><strong>${price}</strong></div>
      <blockquote>"${story}"</blockquote>
      ${moveAction}
      <button type="button" class="ltv-wish-gift" data-gift-add><iconify-icon icon="lucide:gift"></iconify-icon>Add to Gift Builder</button>
    </div>
  </article>`;
}
function initWishlist(){
  const root=document.querySelector("[data-wishlist-page]");
  if(!root)return;
  if(!root.dataset.wishlistDynamic){
    const items=store.get("wishlist");
    root.innerHTML=items.length?`<div class="ltv-page-title"><div><h1>Your Saved Stories</h1><p>These handcrafted pieces carry the voices of their makers. Curate your collection, build a meaningful gift, or bring these stories into your home.</p></div><button class="ltv-btn ltv-btn--terra">Move All to Cart</button></div><div class="ltv-product-grid">${items.map(x=>productCard({...x,artisan:"Saved artisan",city:"India",bundle:true})).join("")}</div>`:`<div class="ltv-center ltv-section"><span class="ltv-eyebrow">Curated for You</span><h1>Your Saved Stories</h1><p>Save the pieces that speak to you. Build a collection of handcrafted treasures and discover the artisans behind them.</p><a class="ltv-btn ltv-btn--terra" href="/collections/all">Explore Collection <iconify-icon icon="lucide:arrow-right"></iconify-icon></a></div><div class="ltv-product-grid">${LTV.products.slice(0,6).map(productCard).join("")}</div>`;
    return;
  }
  const grid=root.querySelector("[data-wishlist-items-grid]");
  const empty=root.querySelector("[data-wishlist-empty]");
  const countEls=document.querySelectorAll("[data-wishlist-item-count]");
  const selectedLabel=document.querySelector("[data-wishlist-selected-label]");
  const getItems=()=>store.get("wishlist");
  function updateSelected(){
    const selected=root.querySelectorAll("[data-wishlist-select]:checked").length;
    if(selectedLabel)selectedLabel.textContent=`${selected} Items Selected`;
  }
  function render(){
    const items=getItems();
    if(grid)grid.innerHTML=items.map(wishlistCard).join("");
    if(empty)empty.hidden=items.length>0;
    const itemLabel=root.dataset.itemsLabel||'items';
    countEls.forEach(el=>{el.textContent=`${items.length} ${items.length===1?'item':itemLabel}`});
    updateSelected();
    store.refreshWishlist();
  }
  root.addEventListener("change",e=>{
    if(e.target.matches("[data-wishlist-select-all]")){
      root.querySelectorAll("[data-wishlist-select]").forEach(input=>{input.checked=e.target.checked});
      updateSelected();
    }
    if(e.target.matches("[data-wishlist-select]"))updateSelected();
  });
  root.addEventListener("click",async e=>{
    const remove=e.target.closest("[data-wishlist-remove]");
    if(remove){
      store.remove("wishlist",remove.dataset.wishlistRemove);
      render();
      return;
    }
    const move=e.target.closest("[data-wishlist-move]");
    if(move){
      const item=getItems().find(x=>x.id===move.dataset.wishlistMove);
      if(item?.variantId)await addToCartAjax(item.variantId,1);
    }
  });
  document.querySelector("[data-wishlist-share]")?.addEventListener("click",async()=>{
    if(navigator.share){try{await navigator.share({title:document.title,url:location.href})}catch(e){}}
    else{try{await navigator.clipboard.writeText(location.href);notify("Wishlist link copied")}catch(e){notify("Copy failed. Use your browser address bar to copy the link.")}}
  });
  document.querySelector("[data-wishlist-move-all]")?.addEventListener("click",async()=>{
    const selected=[...root.querySelectorAll("[data-wishlist-select]:checked")].map(x=>x.value);
    const items=getItems().filter(x=>!selected.length||selected.includes(x.id));
    for(const item of items){if(item.variantId)await addToCartAjax(item.variantId,1)}
  });
  render();
}
function initGift(){
  const root=document.querySelector("[data-gift-builder]");
  if(!root)return;
  const centerEl=root.querySelector("[data-gift-centerpieces]");
  const complementsEl=root.querySelector("[data-gift-complements]");
  const emptyEl=root.querySelector("[data-gift-empty]");
  const summaryEl=root.querySelector("[data-gift-summary]");
  const totalEl=root.querySelector("[data-gift-total]");
  const centerLabel=root.querySelector("[data-gift-center-label]");
  const packLabel=root.querySelector("[data-gift-pack-label]");
  let selectedCenterId="";
  let pack=[...root.querySelectorAll("[data-gift-pack]")].find(x=>x.classList.contains("is-selected"))||root.querySelector("[data-gift-pack]");

  const money=n=>"Rs. "+(Number(n)||0).toLocaleString("en-IN",{maximumFractionDigits:0});
  const image=item=>item.image||"";
  const price=item=>Number(String(item.price||0).replace(/[^0-9.]/g,""))||0;
  const qty=item=>Math.max(1,Number(item.qty||1));
  const getItems=()=>store.get("gift").filter(item=>item.id!=="custom-gift");
  const removeGift=id=>{store.set("gift",store.get("gift").filter(item=>item.id!==id))};
  const card=item=>`<button type="button" class="ltv-option ltv-gift-product-option ${item.id===selectedCenterId?"is-selected":""}" data-gift-center="${item.id}">
    ${image(item)?`<img src="${image(item)}" alt="${item.title||"Gift product"}" loading="lazy" decoding="async">`:''}
    ${qty(item)>1?`<span class="ltv-gift-qty">x${qty(item)}</span>`:""}
    <h4>${item.title||"Gift product"}</h4>
    <p>${item.artisan?`By ${item.artisan}`:""}</p>
    <strong>${money(price(item)*qty(item))}</strong>
    <span class="ltv-gift-remove" role="button" tabindex="0" data-gift-remove="${item.id}" aria-label="Remove ${item.title||"product"}">Remove</span>
  </button>`;
  const accentCard=item=>`<button type="button" class="ltv-option ltv-gift-product-option" data-gift-accent-add data-id="${item.id}" data-title="${item.title||""}" data-price="${price(item)}" data-image="${image(item)}" data-url="${item.url||""}" data-variant-id="${item.variantId||""}" data-artisan="${item.artisan||""}">
    ${image(item)?`<img src="${image(item)}" alt="${item.title||"Accent product"}" loading="lazy" decoding="async">`:''}
    ${qty(item)>1?`<span class="ltv-gift-qty">x${qty(item)}</span>`:""}
    <h4>${item.title||"Accent product"}</h4>
    <p>${item.artisan?`By ${item.artisan}`:""}</p>
    <strong>${money(price(item)*qty(item))}</strong>
    ${item.inGift?`<span class="ltv-gift-remove" role="button" tabindex="0" data-gift-remove="${item.id}" aria-label="Remove ${item.title||"product"}">Remove</span>`:'<span class="ltv-gift-add-accent">Add Accent</span>'}
  </button>`;
  const sourceAccents=()=>[...root.querySelectorAll("[data-gift-accent-option]")].map(button=>({
    id:button.dataset.id,
    title:button.dataset.title,
    price:button.dataset.price,
    image:button.dataset.image,
    url:button.dataset.url,
    variantId:button.dataset.variantId,
    artisan:button.dataset.artisan
  }));

  function selectedPack(){
    return pack?{title:pack.dataset.title||"Gift packaging",price:price(pack.dataset),image:pack.dataset.image||""}:{title:"",price:0,image:""};
  }

  function render(){
    const items=getItems();
    if(!selectedCenterId||!items.some(item=>item.id===selectedCenterId))selectedCenterId=items[0]?.id||"";
    const center=items.find(item=>item.id===selectedCenterId);
    const selectedAccents=items.filter(item=>item.id!==selectedCenterId);
    const selectedIds=new Set(items.map(item=>item.id));
    const accentOptions=[...selectedAccents.map(item=>({...item,inGift:true})),...sourceAccents().filter(item=>item.id!==selectedCenterId&&!selectedIds.has(item.id))];
    if(centerEl)centerEl.innerHTML=items.length?items.map(card).join(""):"";
    if(complementsEl)complementsEl.innerHTML=accentOptions.length?accentOptions.map(accentCard).join(""):'<p class="ltv-gift-note">Choose an accent collection in this section settings or add more bundle-ready products from the collection.</p>';
    if(emptyEl)emptyEl.hidden=items.length>0;
    const packItem=selectedPack();
    const sum=(center?price(center)*qty(center):0)+selectedAccents.reduce((s,item)=>s+price(item)*qty(item),0)+(packItem.title?packItem.price:0);
    if(totalEl)totalEl.textContent=money(sum);
    if(centerLabel)centerLabel.textContent=center?`${center.title} (${money(price(center)*qty(center))})`:"Select a product from your gift builder.";
    if(packLabel&&packItem.title)packLabel.textContent=`${packItem.title} (${money(packItem.price)})`;
    if(summaryEl){
      summaryEl.innerHTML=center?`<div class="ltv-cart-item ltv-gift-summary-item"><img src="${image(center)}" width="64" height="64" alt="" loading="lazy" decoding="async"><div><small>Centerpiece</small><h4>${center.title}${qty(center)>1?` <em>x${qty(center)}</em>`:""}</h4><strong>${money(price(center)*qty(center))}</strong></div><button type="button" data-gift-remove="${center.id}" aria-label="Remove ${center.title}"><iconify-icon icon="lucide:x"></iconify-icon></button></div>${selectedAccents.map(item=>`<div class="ltv-summary-row"><span>${item.title}${qty(item)>1?` x${qty(item)}`:""}</span><strong>${money(price(item)*qty(item))}</strong><button type="button" data-gift-remove="${item.id}" aria-label="Remove ${item.title}"><iconify-icon icon="lucide:x"></iconify-icon></button></div>`).join("")}${packItem.title?`<div class="ltv-summary-row"><span>${packItem.title}</span><strong>${money(packItem.price)}</strong></div>`:""}`:'<p class="ltv-gift-note">Your selected products will appear here.</p>';
    }
  }

  root.querySelectorAll(".ltv-step__head").forEach(h=>h.addEventListener("click",e=>{if(!e.target.closest("button"))h.parentElement.classList.toggle("is-open")}));
  root.addEventListener("click",e=>{
    const remove=e.target.closest("[data-gift-remove]");
    if(remove){
      e.preventDefault();
      e.stopPropagation();
      removeGift(remove.dataset.giftRemove);
      render();
      return;
    }
    const center=e.target.closest("[data-gift-center]");
    if(center){
      selectedCenterId=center.dataset.giftCenter;
      render();
      return;
    }
    const accent=e.target.closest("[data-gift-accent-add]");
    if(accent){
      store.add("gift",{id:accent.dataset.id,title:accent.dataset.title,price:price(accent.dataset),image:accent.dataset.image,url:accent.dataset.url,variantId:accent.dataset.variantId,artisan:accent.dataset.artisan});
      notify("Accent added to gift builder");
      render();
      return;
    }
    const packButton=e.target.closest("[data-gift-pack]");
    if(packButton){
      pack=packButton;
      root.querySelectorAll("[data-gift-pack]").forEach(x=>x.classList.toggle("is-selected",x===packButton));
      render();
    }
  });
  root.querySelector("[data-gift-add-cart]")?.addEventListener("click",()=>{
    const items=getItems();
    if(!items.length){notify("Add a product to your gift builder first");return;}
    notify("Gift set saved");
  });
  render();
}
function initPreferences(){
  const root=document.querySelector("[data-preferences]");
  if(!root)return;
  const language=root.querySelector("[data-pref-language]");
  const currency=root.querySelector("[data-pref-currency]");
  try{
    const saved=JSON.parse(localStorage.getItem("ltv_prefs")||"{}");
    if(saved.language&&language)language.value=saved.language;
    if(saved.currency&&currency)currency.value=saved.currency;
  }catch(e){}
  root.querySelector("[data-pref-save]")?.addEventListener("click",()=>{
    localStorage.setItem("ltv_prefs",JSON.stringify({language:language?.value||"EN",currency:currency?.value||"INR"}));
    notify("Preferences saved");
  });
}
function initSearch(){
  const root=document.querySelector("[data-search-results]");
  if(!root) return;
  const q=new URLSearchParams(location.search).get("q")||"Blue Pottery";
  const queryInput=root.querySelector("[data-search-query]");
  if(queryInput) queryInput.value=q;
  const labelEl=root.querySelector("[data-search-label]");
  if(labelEl) labelEl.textContent=q;
  const resultsEl=root.querySelector("[data-results]");
  if(resultsEl&&!resultsEl.innerHTML.trim()){
    const matches=LTV.products.filter(p=>(p.title+p.craft+p.city).toLowerCase().includes(q.toLowerCase())||q==="Blue Pottery");
    resultsEl.innerHTML=(matches.length?matches:LTV.products.slice(0,6)).map(productCard).join("");
  }
  const filters=root.querySelector("[data-search-filters]");
  const toggle=root.querySelector("[data-search-filter-toggle]");
  const close=root.querySelector("[data-search-filter-close]");
  toggle?.addEventListener("click",()=>{
    const next=!filters?.classList.contains("is-open");
    filters?.classList.toggle("is-open",next);
    toggle.setAttribute("aria-expanded",String(next));
  });
  close?.addEventListener("click",()=>{
    filters?.classList.remove("is-open");
    toggle?.setAttribute("aria-expanded","false");
  });
  root.querySelector(".ltv-search-mobile-controls select")?.addEventListener("change",e=>{
    const form=root.querySelector(".ltv-search-toolbar form");
    const select=form?.querySelector('select[name="sort_by"]');
    if(select&&form){
      select.value=e.target.value;
      form.submit();
    }
  });
  root.querySelector(".ltv-search-bundle-filter input")?.addEventListener("change",()=>{
    root.querySelector(".ltv-search-toolbar form")?.submit();
  });
}
function initFaq(){
  document.querySelectorAll("[data-faq-root]").forEach(root=>{
    const topics=[...root.querySelectorAll("[data-faq-topic]")];
    const panels=[...root.querySelectorAll("[data-faq-panel]")];
    const search=document.querySelector("[data-faq-search]");
    const searchForm=document.querySelector("[data-faq-search-form]");
    const desktopCount=Number(root.dataset.collapsedCount||2);
    const mobileCount=Number(root.dataset.mobileCollapsedCount||4);
    const count=()=>window.matchMedia("(max-width: 760px)").matches?mobileCount:desktopCount;

    function activePanel(){
      return panels.find(panel=>panel.classList.contains("is-active"))||panels[0];
    }

    function applyLimit(panel=activePanel()){
      if(!panel)return;
      const expanded=panel.classList.contains("is-expanded");
      const items=[...panel.querySelectorAll("[data-faq-item]")].filter(item=>!item.dataset.searchHidden);
      const max=count();
      let hidden=0;
      items.forEach((item,index)=>{
        const shouldHide=!expanded&&index>=max;
        item.hidden=shouldHide;
        if(shouldHide)hidden++;
      });
      panel.classList.toggle("has-hidden",hidden>0);
      const button=panel.querySelector("[data-faq-view-all]");
      if(button){
        button.innerHTML=`${expanded?button.dataset.lessLabel:button.dataset.moreLabel} <iconify-icon icon="lucide:arrow-right"></iconify-icon>`;
      }
    }

    function setTopic(topic){
      topics.forEach(button=>{
        const active=button.dataset.faqTopic===topic;
        button.classList.toggle("is-active",active);
        button.setAttribute("aria-pressed",String(active));
      });
      panels.forEach(panel=>{
        const active=panel.dataset.faqPanel===topic;
        panel.classList.toggle("is-active",active);
        if(!active)panel.classList.remove("is-expanded");
        panel.querySelectorAll("details[open]").forEach(item=>item.removeAttribute("open"));
      });
      filterSearch();
      applyLimit();
    }

    function filterSearch(){
      const query=(search?.value||"").trim().toLowerCase();
      panels.forEach(panel=>{
        let visible=0;
        panel.querySelectorAll("[data-faq-item]").forEach(item=>{
          const text=item.textContent.toLowerCase();
          const hide=Boolean(query)&&!text.includes(query);
          item.dataset.searchHidden=hide?"true":"";
          if(hide)item.hidden=true;
          else visible++;
        });
        panel.classList.toggle("is-search-empty",Boolean(query)&&visible===0);
      });
    }

    topics.forEach(button=>button.addEventListener("click",()=>setTopic(button.dataset.faqTopic)));
    panels.forEach(panel=>{
      panel.querySelector("[data-faq-view-all]")?.addEventListener("click",()=>{
        panel.classList.toggle("is-expanded");
        applyLimit(panel);
      });
    });
    search?.addEventListener("input",()=>{
      panels.forEach(panel=>panel.classList.add("is-expanded"));
      filterSearch();
      applyLimit();
    });
    searchForm?.addEventListener("submit",e=>e.preventDefault());
    window.addEventListener("resize",()=>panels.forEach(panel=>applyLimit(panel)));
    setTopic(root.dataset.initialTopic||topics[0]?.dataset.faqTopic);
  });

  document.addEventListener("keydown",e=>{
    if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){
      const search=document.querySelector("[data-faq-search]");
      if(search){
        e.preventDefault();
        search.focus();
      }
    }
  });
}
function initCollectionPage(){
  document.querySelectorAll("[data-collection-page]").forEach(root=>{
    const filters=root.querySelector("[data-collection-filters]");
    const openButtons=root.querySelectorAll("[data-collection-filter-open]");
    const closeButton=root.querySelector("[data-collection-filter-close]");
    const bundleToggles=root.querySelectorAll("[data-collection-bundle-toggle]");
    const setFilters=open=>{
      root.classList.toggle("is-filters-open",open);
      filters?.setAttribute("aria-hidden",String(!open));
      openButtons.forEach(button=>button.setAttribute("aria-expanded",String(open)));
      document.body.classList.toggle("ltv-collection-filter-open",open);
    };
    openButtons.forEach(button=>button.addEventListener("click",()=>setFilters(true)));
    closeButton?.addEventListener("click",()=>setFilters(false));
    filters?.addEventListener("click",e=>{if(e.target.matches("a"))setFilters(false)});
    document.addEventListener("keydown",e=>{if(e.key==="Escape")setFilters(false)});

    const setBundleVisible=visible=>{
      root.classList.toggle("is-bundle-visible",visible);
      bundleToggles.forEach(toggle=>{toggle.checked=visible});
    };
    if(bundleToggles.length){
      setBundleVisible([...bundleToggles].some(toggle=>toggle.checked));
      bundleToggles.forEach(toggle=>toggle.addEventListener("change",()=>setBundleVisible(toggle.checked)));
    }
  });
}
function initOrderTracking(){
  const root=document.querySelector("[data-order-tracking]");
  if(!root)return;
  const endpoint=root.dataset.endpoint;
  const demo=root.dataset.demo==="true";
  const content=root.querySelector("[data-track-content]");
  const loading=root.querySelector("[data-track-loading]");
  const empty=root.querySelector("[data-track-empty]");
  const emptyHeading=root.querySelector("[data-track-empty-heading]");
  const emptyText=root.querySelector("[data-track-empty-text]");
  const params=new URLSearchParams(location.search);
  const order=params.get("order")||root.dataset.order||"";
  if(order)root.dataset.order=order;
  const setPanel=(state,heading,text)=>{
    if(content)content.hidden=state!=="content";
    if(loading)loading.hidden=state!=="loading";
    if(empty)empty.hidden=state!=="empty";
    if(state==="empty"){
      if(heading&&emptyHeading)emptyHeading.textContent=heading;
      if(text&&emptyText)emptyText.textContent=text;
    }
  };

  const setText=(selector,value)=>{
    if(value===undefined||value===null||value==="")return;
    const el=root.querySelector(selector);
    if(el)el.textContent=value;
  };
  const forceText=(selector,value)=>{
    const el=root.querySelector(selector);
    if(el)el.textContent=value||"";
  };
  const setHref=(selector,value)=>{
    if(!value)return;
    const el=root.querySelector(selector);
    if(el)el.href=value;
  };
  const toggle=(selector,visible)=>{
    const el=root.querySelector(selector);
    if(el)el.hidden=!visible;
  };
  const setImage=(selector,value,alt,containerSelector)=>{
    if(!value)return;
    let img=root.querySelector(selector);
    if(!img&&containerSelector){
      const container=root.querySelector(containerSelector);
      if(container){
        img=document.createElement("img");
        img.setAttribute(selector.replace(/^\[/,"").replace(/\]$/,""),"");
        container.prepend(img);
        container.querySelector("[data-track-map-art]")?.remove();
      }
    }
    if(!img)return;
    img.src=value;
    if(alt)img.alt=alt;
  };
  const normalizeStatus=status=>{
    const value=String(status||"").toLowerCase();
    if(["complete","completed","done","delivered"].includes(value))return "complete";
    if(["active","current","in_transit","in-transit","shipped","out_for_delivery"].includes(value))return "active";
    return "pending";
  };
  const iconForStatus=status=>status==="complete"?"lucide:check":status==="active"?"lucide:truck":"lucide:map-pin";
  const renderTimeline=events=>{
    const timeline=root.querySelector("[data-track-timeline]");
    if(!timeline||!Array.isArray(events)||!events.length)return;
    timeline.innerHTML=events.map(event=>{
      const status=normalizeStatus(event.status);
      const icon=esc(event.icon||iconForStatus(status));
      return `<article class="ltv-track-event ${status==="complete"?"is-complete":status==="active"?"is-active":""}">
        <div class="ltv-track-event__icon"><iconify-icon icon="${icon}"></iconify-icon></div>
        <div>
          <h3>${esc(event.title||"")}</h3>
          <p>${esc(event.text||"")}</p>
          ${event.notice?`<div class="ltv-track-notice"><iconify-icon icon="lucide:info"></iconify-icon>${esc(event.notice)}</div>`:""}
        </div>
        <time>${esc(event.date||"")}</time>
      </article>`;
    }).join("");
  };
  const renderCare=items=>{
    const list=root.querySelector("[data-track-care-list]");
    if(!list||!Array.isArray(items)||!items.length)return;
    list.innerHTML=items.map(item=>`<article>
      <iconify-icon icon="${esc(item.icon||"lucide:sparkles")}"></iconify-icon>
      <div>
        <h3>${esc(item.title||"")}</h3>
        <p>${esc(item.text||item.description||"")}</p>
      </div>
    </article>`).join("");
  };
  const renderRelated=items=>{
    const list=root.querySelector("[data-track-related-list]");
    if(!list||!Array.isArray(items)||!items.length)return;
    list.innerHTML=items.map(item=>{
      const image=item.image||item.image_url||"";
      const body=`${image?`<img src="${esc(image)}" alt="${esc(item.title||"Related product")}">`:""}
        <h3>${esc(item.title||"")}</h3>
        <p>${esc(item.price||"")}</p>`;
      return item.url?`<article><a href="${esc(item.url)}">${body}</a></article>`:`<article>${body}</article>`;
    }).join("");
  };
  const addressText=address=>{
    if(!address)return "";
    if(typeof address==="string")return address;
    const lines=Array.isArray(address.lines)?address.lines:[address.line1,address.line2].filter(Boolean);
    return [address.name,...lines,address.city,address.province||address.state,address.zip||address.postal_code,address.country].filter(Boolean).join("\n");
  };
  const hasRealTrackingData=data=>{
    if(!data||data.error||data.not_found)return false;
    return Boolean(data.order_number||data.order_name||data.name||data.timeline?.length||data.events?.length||data.shipment||data.fulfillment||data.fulfillments?.length);
  };
  const hasObjectData=obj=>obj&&Object.values(obj).some(value=>Array.isArray(value)?value.length:Boolean(value));

  setText("[data-track-order-label]",order);
  if(demo){
    setPanel("content");
    return;
  }
  if(!order){
    setPanel("empty",root.dataset.emptyHeading,root.dataset.emptyText);
    return;
  }
  if(!endpoint){
    setPanel("empty",root.dataset.apiMissingHeading,root.dataset.apiMissingText);
    return;
  }
  setPanel("loading");

  try{
    const url=new URL(endpoint,location.origin);
    if(order&&!url.searchParams.has("order"))url.searchParams.set("order",order);
    fetch(url.toString(),{headers:{"Accept":"application/json"}})
      .then(response=>response.ok?response.json():null)
      .then(data=>{
        if(!hasRealTrackingData(data)){
          setPanel("empty",root.dataset.notFoundHeading,root.dataset.notFoundText);
          return;
        }
        const shipment=data.shipment||data.fulfillment||data.fulfillments?.[0]||{};
        const product=data.product||data.item||data.line_item||data.line_items?.[0]||{};
        const maker=data.maker||data.artisan||product.maker||product.artisan||{};
        const address=data.address||data.delivery_address||data.shipping_address||data.shippingAddress;
        const events=data.timeline||data.events||shipment.timeline||shipment.events||shipment.checkpoints;
        const careItems=data.care?.items||data.care_items;
        const relatedItems=data.related?.items||data.related_products||data.recommendations;
        const productVisible=hasObjectData(product);
        const makerVisible=hasObjectData(maker);
        const eventsVisible=Boolean(events?.length);
        forceText("[data-track-order-label]",data.order_number||data.order_name||data.name||order);
        forceText("[data-track-heading]",data.heading||"Your order journey is being updated.");
        forceText("[data-track-delivery]",data.estimated_delivery||data.delivery_date||shipment.estimated_delivery||shipment.estimated_delivery_at||"Awaiting carrier update");
        setText(".ltv-track-heading-row h2",data.journey_heading);
        forceText("[data-track-origin]",data.origin||shipment.origin||shipment.origin_location||"Origin pending");
        setText("[data-track-carrier]",data.carrier||data.carrier_label||shipment.carrier||shipment.tracking_company);
        forceText("[data-track-destination]",data.destination||shipment.destination||shipment.destination_location||"Destination pending");
        toggle("[data-track-product]",productVisible);
        forceText("[data-track-product-title]",product.title);
        forceText("[data-track-product-meta]",product.meta||product.description);
        toggle("[data-track-maker]",makerVisible);
        forceText("[data-track-maker-name]",maker.name);
        forceText("[data-track-maker-location]",maker.location);
        forceText("[data-track-maker-message]",maker.message);
        toggle("[data-track-care]",Boolean(data.care||careItems?.length));
        forceText("[data-track-care-heading]",data.care?.heading||"Care & Rituals");
        forceText("[data-track-care-text]",data.care?.text||data.care?.description);
        setText("[data-track-address-heading]",address?.heading);
        toggle("[data-track-address]",Boolean(address));
        forceText("[data-track-address-text]",addressText(address));
        setText("[data-track-related-heading]",data.related_heading||data.related?.heading);
        toggle("[data-track-related]",Boolean(relatedItems?.length));
        setHref(".ltv-track-heading-row a",data.receipt_url||data.order_status_url||data.status_url);
        toggle(".ltv-track-heading-row a",Boolean(data.receipt_url||data.order_status_url||data.status_url));
        toggle(".ltv-track-actions .ltv-track-primary",Boolean(data.more_url||maker.url));
        setHref(".ltv-track-actions .ltv-track-primary",data.more_url||maker.url);
        setHref(".ltv-track-actions .ltv-track-secondary",data.support_url);
        toggle(".ltv-track-mobile-actions .ltv-track-primary",Boolean(data.details_url||data.order_status_url||data.status_url||shipment.tracking_url||data.more_url));
        setHref(".ltv-track-mobile-actions .ltv-track-primary",data.details_url||data.order_status_url||data.status_url||shipment.tracking_url||data.more_url);
        setHref(".ltv-track-mobile-actions .ltv-track-secondary",data.support_url);
        setHref("[data-track-maker-video]",maker.video_url);
        setImage("[data-track-map-img]",data.map_image||data.map?.image,data.journey_heading,".ltv-track-map");
        setImage("[data-track-product-img]",product.image||product.image_url,product.title);
        setImage("[data-track-maker-img]",maker.image||maker.image_url,maker.name);
        toggle(".ltv-track-timeline-card",productVisible||eventsVisible);
        toggle("[data-track-timeline]",eventsVisible);
        renderTimeline(events);
        renderCare(careItems);
        renderRelated(relatedItems);
        setPanel("content");
      })
      .catch(error=>{
        console.warn("Order tracking endpoint failed",error);
        setPanel("empty",root.dataset.notFoundHeading,root.dataset.notFoundText);
      });
  }catch(error){
    console.warn("Invalid order tracking endpoint",error);
    setPanel("empty",root.dataset.apiMissingHeading,root.dataset.apiMissingText);
  }
}
function initCitiesFilters(){
  const filters=document.querySelector("[data-city-filters]");
  const cards=[...document.querySelectorAll("[data-city-card]")];
  if(!filters||!cards.length)return;
  const countCards=[...document.querySelectorAll("[data-city-grid] [data-city-card]")];
  const state={region:"all",craft:"all"};
  const countEl=document.querySelector("[data-city-count]");
  const emptyEl=document.querySelector("[data-city-filter-empty]");
  const apply=()=>{
    let visible=0;
    let visibleInGrid=0;
    cards.forEach(card=>{
      const regionMatch=state.region==="all"||card.dataset.region===state.region;
      const craftMatch=state.craft==="all"||(card.dataset.crafts||"").split(/\s+/).includes(state.craft);
      const show=regionMatch&&craftMatch;
      card.hidden=!show;
      if(show)visible+=1;
    });
    countCards.forEach(card=>{if(!card.hidden)visibleInGrid+=1});
    if(countEl)countEl.textContent=`Showing ${visibleInGrid} ${visibleInGrid===1?"destination":"destinations"}`;
    if(emptyEl)emptyEl.hidden=visibleInGrid>0;
  };
  filters.addEventListener("click",event=>{
    const button=event.target.closest("[data-city-filter]");
    if(!button)return;
    const type=button.dataset.cityFilter;
    state[type]=button.dataset.cityValue||"all";
    filters.querySelectorAll(`[data-city-filter="${type}"]`).forEach(item=>item.classList.toggle("is-active",item===button));
    apply();
  });
  apply();
}
document.addEventListener("DOMContentLoaded",()=>{bindCommon();initGrids();initProduct();initStoriesPage();initVideoPreviews();initInlineVideos();initCart();initWishlist();initGift();initPreferences();initSearch();initFaq();initCollectionPage();initOrderTracking();initCitiesFilters()});

