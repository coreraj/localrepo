(function () {
  const dashboard = document.querySelector('[data-customer-dashboard]');
  if (!dashboard) return;

  const panels = dashboard.querySelectorAll('[data-dashboard-panel]');
  panels.forEach((panel, index) => {
    panel.classList.toggle('is-open', index === 0);
    const toggle = panel.querySelector('.customer-dashboard__panel-toggle');
    if (!toggle) return;
    toggle.setAttribute('aria-expanded', index === 0 ? 'true' : 'false');
    toggle.addEventListener('click', () => {
      const isOpen = panel.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  });

  dashboard.addEventListener('click', (event) => {
    const opener = event.target.closest('[data-address-open]');
    if (opener) {
      const id = opener.dataset.addressOpen;
      const form = dashboard.querySelector(`[data-address-form="${id}"]`);
      if (form) {
        dashboard.querySelectorAll('[data-address-form]').forEach((item) => {
          item.hidden = item !== form;
        });
        form.hidden = false;
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    if (event.target.closest('[data-address-close]')) {
      const form = event.target.closest('[data-address-form]');
      if (form) form.hidden = true;
    }
  });

  dashboard.querySelectorAll('[data-address-delete]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!window.confirm('Remove this saved address?')) {
        event.preventDefault();
      }
    });
  });

  const wishlistRoot = dashboard.querySelector('[data-dashboard-wishlist]');
  if (!wishlistRoot) return;

  let items = [];
  try {
    items = JSON.parse(localStorage.getItem('ltv_wishlist') || '[]');
  } catch (error) {
    items = [];
  }

  if (!Array.isArray(items) || items.length === 0) return;

  const money = (value) => {
    const amount = Number(value || 0);
    if (!amount) return '';
    return new Intl.NumberFormat(document.documentElement.lang || 'en', {
      style: 'currency',
      currency: window.Shopify?.currency?.active || 'USD'
    }).format(amount);
  };

  wishlistRoot.innerHTML = '<div class="customer-dashboard__wishlist-grid"></div>';
  const grid = wishlistRoot.querySelector('.customer-dashboard__wishlist-grid');
  items.slice(0, 6).forEach((item) => {
    const card = document.createElement('article');
    card.className = 'customer-dashboard__wishlist-card';

    const image = document.createElement('img');
    image.src = item.image || '';
    image.alt = item.title || 'Saved product';
    image.loading = 'lazy';
    card.appendChild(image);

    const body = document.createElement('div');
    const title = document.createElement('h4');
    title.textContent = item.title || 'Saved product';
    body.appendChild(title);

    const price = document.createElement('strong');
    price.textContent = money(item.price);
    body.appendChild(price);

    const link = document.createElement('a');
    link.href = item.id ? `/products/${item.id}` : '/pages/wishlist';
    link.textContent = 'View details';
    body.appendChild(link);

    card.appendChild(body);
    grid.appendChild(card);
  });

  const discover = document.createElement('a');
  discover.className = 'customer-dashboard__discover-card';
  discover.href = '/collections/all';
  discover.innerHTML = '<span><iconify-icon icon="lucide:plus"></iconify-icon></span><strong>Discover More</strong><small>Explore artisans to add items to your wishlist.</small>';
  grid.appendChild(discover);
})();
