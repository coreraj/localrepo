const LTV={products:[
{id:"azure-heritage-vase",title:"The Azure Heritage Vase",price:145,compare:175,image:"https://images.unsplash.com/photo-1546454272-5914d75c01e9?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1546454272-5914d75c01e9?w=800&h=800&fit=crop","https://images.unsplash.com/photo-1716222324740-0770c29282b9?w=800&h=800&fit=crop","https://images.unsplash.com/photo-1715845883469-54c2486a0a82?w=800&h=800&fit=crop"],artisan:"Priya Sharma",city:"Khurja",craft:"Blue Pottery",rating:4.5,reviews:24,bundle:true,description:"A masterpiece of Khurja's blue pottery tradition, this vase features hand-painted cobalt patterns inspired by Mughal architecture.",materials:"Quartz, raw glaze, cobalt oxide, natural minerals",dimensions:"12 H x 6 W x 6 D"},
{id:"crimson-raku-bowl",title:"Crimson Raku Bowl Set",price:89,image:"https://images.unsplash.com/photo-1615640325967-af4cfa4c0c6a?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1615640325967-af4cfa4c0c6a?w=800&h=800&fit=crop"],artisan:"Priya Sharma",city:"Khurja",craft:"Blue Pottery",rating:4.8,reviews:31,bundle:true,description:"A set of four hand-glazed bowls with a stunning crimson raku finish, perfect for serving or display."},
{id:"indigo-block-scarf",title:"Indigo Block Print Scarf",price:65,compare:80,image:"https://images.unsplash.com/photo-1608793733118-ee3f16002251?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1608793733118-ee3f16002251?w=800&h=800&fit=crop"],artisan:"Rajan Mehta",city:"Jaipur",craft:"Block Printing",rating:4.3,reviews:18,bundle:true,description:"Hand-stamped with traditional wooden blocks using natural indigo dye on pure cotton."},
{id:"varanasi-silk-stole",title:"Varanasi Silk Brocade Stole",price:195,compare:240,image:"https://images.pexels.com/photos/18363710/pexels-photo-18363710.jpeg?w=600&h=600&fit=crop",images:["https://images.pexels.com/photos/18363710/pexels-photo-18363710.jpeg?w=800&h=800&fit=crop"],artisan:"Lakshmi Devi",city:"Varanasi",craft:"Silk Weaving",rating:4.7,reviews:42,bundle:false,description:"Luxurious hand-woven silk stole with intricate gold brocade motifs from the looms of Varanasi."},
{id:"terracotta-planter",title:"Terracotta Garden Planter",price:78,image:"https://images.unsplash.com/photo-1531452454767-de8511addfdf?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1531452454767-de8511addfdf?w=800&h=800&fit=crop"],artisan:"Priya Sharma",city:"Khurja",craft:"Blue Pottery",rating:4.2,reviews:15,bundle:true,description:"A beautifully handcrafted terracotta planter with traditional Khurja blue glaze accents."},
{id:"rosewood-jewelry-box",title:"Hand-carved Rosewood Box",price:120,compare:150,image:"https://images.unsplash.com/photo-1680777019951-9cc1abaa0471?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1680777019951-9cc1abaa0471?w=800&h=800&fit=crop"],artisan:"Amir Khan",city:"Srinagar",craft:"Wood Carving",rating:4.6,reviews:27,bundle:true,description:"Intricately carved rosewood jewelry box featuring traditional Kashmiri motifs."},
{id:"brass-diya-set",title:"Brass Diya Lamp Set",price:55,image:"https://images.unsplash.com/photo-1552590854-5b55d5425066?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1552590854-5b55d5425066?w=800&h=800&fit=crop"],artisan:"Amir Khan",city:"Moradabad",craft:"Brassware",rating:4.4,reviews:19,bundle:true,description:"Set of five hand-cast brass diya lamps with intricate engraving, perfect for festivals."},
{id:"pashmina-shawl",title:"Kashmir Pashmina Shawl",price:250,compare:320,image:"https://images.unsplash.com/photo-1598616068517-c75ad397a436?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1598616068517-c75ad397a436?w=800&h=800&fit=crop"],artisan:"Fatima Bi",city:"Srinagar",craft:"Silk Weaving",rating:4.9,reviews:56,bundle:false,description:"Luxuriously soft hand-woven pashmina shawl with traditional Kashmiri sozni embroidery."},
{id:"blue-pottery-tea-set",title:"Blue Pottery Tea Set",price:110,image:"https://images.unsplash.com/photo-1716222324740-0770c29282b9?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1716222324740-0770c29282b9?w=800&h=800&fit=crop"],artisan:"Rajan Mehta",city:"Jaipur",craft:"Blue Pottery",rating:4.5,reviews:33,bundle:true,description:"A charming tea set in traditional Jaipur blue pottery style with floral motifs."},
{id:"silver-filigree-earrings",title:"Silver Filigree Earrings",price:85,compare:100,image:"https://images.unsplash.com/photo-1722510825242-0d8f2064c2e2?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1722510825242-0d8f2064c2e2?w=800&h=800&fit=crop"],artisan:"Meera Devi",city:"Moradabad",craft:"Filigree",rating:4.7,reviews:38,bundle:true,description:"Delicate silver filigree earrings featuring traditional Odissi motifs."},
{id:"bidri-vase",title:"Bidri Art Vase",price:135,compare:165,image:"https://images.unsplash.com/photo-1715845883469-54c2486a0a82?w=600&h=600&fit=crop",images:["https://images.unsplash.com/photo-1715845883469-54c2486a0a82?w=800&h=800&fit=crop"],artisan:"Fatima Bi",city:"Bidar",craft:"Bidri Work",rating:4.3,reviews:12,bundle:false,description:"Stunning Bidri art vase with pure silver inlay on oxidized zinc alloy."},
{id:"kantha-cushion",title:"Kantha Embroidered Cushion",price:45,image:"https://images.pexels.com/photos/15131488/pexels-photo-15131488.jpeg?w=600&h=600&fit=crop",images:["https://images.pexels.com/photos/15131488/pexels-photo-15131488.jpeg?w=800&h=800&fit=crop"],artisan:"Meera Devi",city:"Jaipur",craft:"Kantha Embroidery",rating:4.6,reviews:21,bundle:true,description:"Vibrant cushion cover featuring traditional Kantha running stitch embroidery."}
],cities:[["khurja","Khurja","Blue Pottery","The Ceramic City","https://images.unsplash.com/photo-1630042924261-7453b1957f5c?w=800&h=500&fit=crop"],["jaipur","Jaipur","Block Printing & Blue Pottery","The Pink City of Crafts","https://images.unsplash.com/photo-1607160913542-6234aae47ec5?w=800&h=500&fit=crop"],["varanasi","Varanasi","Silk Weaving","The City of Weavers","https://images.unsplash.com/photo-1561028341-d1fbd27889b2?w=800&h=500&fit=crop"],["moradabad","Moradabad","Brassware","Brass City of India","https://images.unsplash.com/photo-1552590854-5b55d5425066?w=800&h=500&fit=crop"],["srinagar","Srinagar","Wood Carving & Pashmina","Paradise of Craftsmanship","https://images.unsplash.com/photo-1511729530272-7198cdce7b8a?w=800&h=500&fit=crop"],["bidar","Bidar","Bidri Work","City of Silver & Shadow","https://images.pexels.com/photos/19035171/pexels-photo-19035171.jpeg?w=800&h=500&fit=crop"]]};
const store={
  get(k){
    try{return JSON.parse(localStorage.getItem("ltv_"+k)||"[]")}catch(e){return[]}
  },
  set(k,v){
    localStorage.setItem("ltv_"+k,JSON.stringify(v));
    this.refresh();
  },
  add(k,item){
    const a=this.get(k);
    const i=a.findIndex(x=>x.id===item.id);
    if(i>-1){
      a[i].qty=(a[i].qty||1)+1;
    } else {
      a.push({...item,qty:1});
    }
    this.set(k,a);
  },
  remove(k,id){
    this.set(k,this.get(k).filter(x=>x.id!==id));
  },
  refresh(){
    this.refreshWishlist();
    this.refreshGift();
    refreshCartCount();
  },
  refreshWishlist(){
    document.querySelectorAll("[data-wishlist-count]").forEach(e=>{const n=this.get("wishlist").length;e.textContent=n?n:""});
  },
  refreshGift(){
    document.querySelectorAll("[data-gift-count]").forEach(e=>{const n=this.get("gift").length;e.textContent=n?n:""});
  }
};
function productCard(p){const variantId=p.variantId||p.id;const url=p.url||`/products/${p.id}`;return `<article class="ltv-product-card" data-product-card data-id="${p.id}" data-title="${p.title}" data-price="${p.price}" data-image="${p.image}" data-url="${url}" data-variant-id="${variantId}" data-artisan="${p.artisan||''}" data-city="${p.city||''}" data-story="${p.description||''}"><a class="ltv-product-card__image" href="${url}"><img src="${p.image}" alt="${p.title}" loading="lazy">${p.bundle?'<span class="ltv-badge"><iconify-icon icon="lucide:package"></iconify-icon>Bundle Ready</span>':''}<div class="ltv-card-actions"><button type="button" class="ltv-circle-btn" data-wishlist-add><iconify-icon icon="lucide:heart"></iconify-icon></button><button type="button" class="ltv-circle-btn ltv-circle-btn--terra" data-local-cart-add data-variant-id="${variantId}" aria-label="Add to cart"><iconify-icon icon="lucide:shopping-bag"></iconify-icon></button></div></a><div class="ltv-product-card__body"><div class="ltv-product-card__row"><h3><a href="${url}">${p.title}</a></h3><strong>₹${p.price}</strong></div><p><iconify-icon icon="lucide:user"></iconify-icon>${p.artisan}<span></span><iconify-icon icon="lucide:map-pin"></iconify-icon>${p.city}</p></div></article>`}

async function refreshCartCount(){
  try{
    const response=await fetch('/cart.js');
    if(!response.ok)return;
    const cart=await response.json();
    document.querySelectorAll('[data-cart-count]').forEach(e=>{e.textContent=cart.item_count?cart.item_count:''});
  }catch(e){console.warn('Unable to refresh cart count',e)}
}

async function addToCartAjax(variantId,quantity=1){
  if(!variantId)return false;
  try{
    const response=await fetch('/cart/add.js',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:variantId,quantity})});
    if(response.ok){
      refreshCartCount();
      return true;
    }
  }catch(e){console.warn('Add to cart failed',e)}
  return false;
}

function bindCommon(){
  store.refresh();
  const closeMega=()=>document.querySelectorAll('[data-mega]').forEach(m=>m.classList.remove('is-open'));
  const openMega=name=>document.querySelectorAll('[data-mega]').forEach(m=>m.classList.toggle('is-open',m.dataset.mega===name));
  document.querySelectorAll('[data-mega-trigger]').forEach(a=>{
    a.addEventListener('mouseenter',()=>openMega(a.dataset.megaTrigger));
    a.addEventListener('focus',()=>openMega(a.dataset.megaTrigger));
    a.addEventListener('click',e=>{
      const menu=document.querySelector(`[data-mega="${a.dataset.megaTrigger}"]`);
      if(!menu)return;
      e.preventDefault();
      menu.classList.contains('is-open')?closeMega():openMega(a.dataset.megaTrigger);
    });
  });
  document.querySelector('[data-ltv-header]')?.addEventListener('mouseleave',closeMega);
  document.addEventListener('click',e=>{if(!e.target.closest('[data-ltv-header]'))closeMega()});
  document.querySelector('[data-mobile-open]')?.addEventListener('click',()=>document.querySelector('[data-mobile-menu]')?.classList.add('is-open'));
  document.querySelector('[data-mobile-close]')?.addEventListener('click',()=>document.querySelector('[data-mobile-menu]')?.classList.remove('is-open'));
  document.body.addEventListener('click',async e=>{
    const cartButton=e.target.closest('[data-local-cart-add]');
    if(cartButton){
      const form=cartButton.closest('form');
      const variantId=cartButton.dataset.variantId||form?.querySelector('[name="id"]')?.value;
      if(!variantId) return;
      e.preventDefault();
      const added=await addToCartAjax(variantId,Number(cartButton.dataset.quantity||1));
      if(!added&&form) form.submit();
      return;
    }
    const wishlistButton=e.target.closest('[data-wishlist-add]');
    if(wishlistButton){
      e.preventDefault();
      const card=wishlistButton.closest('[data-product-card]');
      if(!card)return;
      store.add('wishlist',{id:card.dataset.id,title:card.dataset.title,price:card.dataset.price,image:card.dataset.image,url:card.dataset.url,variantId:card.dataset.variantId,artisan:card.dataset.artisan,city:card.dataset.city,story:card.dataset.story});
      return;
    }
    const giftButton=e.target.closest('[data-gift-add]');
    if(giftButton){
      e.preventDefault();
      const card=giftButton.closest('[data-product-card]');
      const item=card?{id:card.dataset.id,title:card.dataset.title,price:Number(card.dataset.price),image:card.dataset.image} : {id:'gift-item',title:'Artisan Gift',price:0,image:''};
      store.add('gift',item);
      return;
    }
  });
}
function initGrids(){document.querySelectorAll("[data-products-grid]").forEach(el=>{if(!el.innerHTML.trim()){let arr=LTV.products;if(el.dataset.limit)arr=arr.slice(0,+el.dataset.limit);el.innerHTML=arr.map(productCard).join("")}});document.querySelectorAll("[data-cities-grid]").forEach(el=>{if(!el.innerHTML.trim()){el.innerHTML=LTV.cities.slice(0,el.dataset.limit||99).map(c=>`<a href="/pages/cities#${c[0]}" class="ltv-city-card"><img src="${c[4]}" alt="${c[1]}"><h3>${c[1]}</h3><p>Famed for: ${c[2]}</p></a>`).join("")}})}
function initProduct(){
  const root=document.querySelector("[data-product-detail]");
  if(!root) return;
  const mainImg=root.querySelector("[data-p-main]");
  const lightbox=root.querySelector("[data-p-lightbox]");
  const lightboxImg=root.querySelector("[data-p-lightbox-img]");
  const thumbsEl=root.querySelector("[data-p-thumbs]");
  if(thumbsEl){
    thumbsEl.addEventListener("click",e=>{
      const b=e.target.closest("button");
      if(!b) return;
      if(mainImg) mainImg.src=b.dataset.thumb;
      if(lightboxImg) lightboxImg.src=b.dataset.thumb;
      thumbsEl.querySelectorAll("button").forEach(x=>x.classList.toggle("is-active",x===b));
    });
  }
  root.querySelector("[data-p-zoom-open]")?.addEventListener("click",()=>{if(lightbox) lightbox.hidden=false});
  root.querySelector("[data-p-zoom-close]")?.addEventListener("click",()=>{if(lightbox) lightbox.hidden=true});
  lightbox?.addEventListener("click",e=>{if(e.target===lightbox) lightbox.hidden=true});
  root.querySelector("[data-ltv-share]")?.addEventListener("click",async()=>{
    const title=root.dataset.title||document.title;
    const url=location.href;
    if(navigator.share){
      try{await navigator.share({title,url})}catch(e){}
      return;
    }
    try{
      await navigator.clipboard.writeText(url);
      alert("Product link copied");
    }catch(e){
      prompt("Copy product link",url);
    }
  });
  root.querySelectorAll("[data-bundle-builder]").forEach(builder=>{
    const totalEl=builder.querySelector("[data-bundle-total]");
    const savingsEl=builder.querySelector("[data-bundle-savings]");
    const base=Number(builder.dataset.basePrice||0);
    function update(){
      let total=base;
      let savings=0;
      builder.querySelectorAll("[data-bundle-item]").forEach(input=>{
        const item=input.closest(".ltv-pdp-bundle__item");
        item?.classList.toggle("is-selected",input.checked);
        if(input.checked) total+=Number(input.dataset.price||0);
        const oldText=item?.querySelector("s")?.textContent?.replace(/[^0-9.]/g,"");
        if(input.checked&&oldText) savings+=Math.max(0,Number(oldText)-Number(input.dataset.price||0));
      });
      if(totalEl) totalEl.textContent="₹"+total.toFixed(0);
      if(savingsEl) savingsEl.textContent=savings>0?"You save ₹"+savings.toFixed(0):"";
    }
    builder.addEventListener("change",e=>{if(e.target.matches("[data-bundle-item]")) update()});
    update();
  });
}
function initStoriesPage(){
  const root=document;
  if(!document.querySelector("[data-stories-filter], [data-story-item], [data-stories-page]")) return;
  let active="all";
  const bundle=root.querySelector("[data-bundle-filter]");
  function apply(){
    root.querySelectorAll("[data-story-item]").forEach(item=>{
      const category=item.dataset.category;
      const bundleOk=!bundle?.checked||item.dataset.bundle==="true";
      const categoryOk=active==="all"||category===active;
      item.classList.toggle("is-hidden",!(bundleOk&&categoryOk));
    });
  }
  root.querySelectorAll("[data-story-filter]").forEach(button=>{
    button.addEventListener("click",()=>{
      active=button.dataset.storyFilter;
      root.querySelectorAll("[data-story-filter]").forEach(x=>x.classList.toggle("is-active",x===button));
      apply();
    });
  });
  bundle?.addEventListener("change",apply);
  root.querySelector("[data-video-play]")?.addEventListener("click",()=>alert("Video module ready: connect this block to a hosted video or Shopify media asset."));
  apply();
}
function initCart(){
  const root=document.querySelector("[data-local-cart]");
  if(!root)return;
  root.addEventListener("click",e=>{
    const stepButton=e.target.closest("[data-cart-qty-step]");
    if(!stepButton)return;
    const qty=stepButton.closest(".ltv-cart-qty")?.querySelector('input[name="updates[]"]');
    if(!qty)return;
    const next=Math.max(Number(qty.min||0),Number(qty.value||0)+Number(stepButton.dataset.cartQtyStep||0));
    qty.value=next;
    qty.dispatchEvent(new Event("change",{bubbles:true}));
  });
}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function moneyText(v){const s=String(v??'').trim();if(!s)return'';return /[$₹€£]/.test(s)?s:`$${s}`}
function wishlistCard(item){
  const id=esc(item.id||item.title);
  const title=esc(item.title||'Saved Product');
  const url=esc(item.url||'#');
  const image=esc(item.image||'');
  const price=esc(moneyText(item.price));
  const artisan=esc(item.artisan||'Local Artisan');
  const city=esc(item.city||'');
  const story=esc(item.story||'This saved piece carries the voice of its maker and the story of its craft.');
  const variant=item.variantId?`data-variant-id="${esc(item.variantId)}"`:'';
  return `<article class="ltv-wish-card" data-wishlist-item data-product-card data-id="${id}" data-title="${title}" data-price="${esc(item.price||'')}" data-image="${image}" data-url="${url}" ${variant}>
    <label class="ltv-wish-check"><input type="checkbox" data-wishlist-select value="${id}"><span></span></label>
    <button type="button" class="ltv-wish-remove" data-wishlist-remove="${id}" aria-label="Remove ${title}"><iconify-icon icon="lucide:trash-2"></iconify-icon></button>
    <a href="${url}"><img class="ltv-wish-card__image" src="${image}" alt="${title}"></a>
    <div class="ltv-wish-card__body">
      <div class="ltv-wish-maker"><span class="ltv-wish-maker__avatar">${artisan.charAt(0)}</span><div><strong>${artisan}</strong><span><iconify-icon icon="lucide:map-pin"></iconify-icon>${city}</span></div></div>
      <div class="ltv-wish-title-row"><h2><a href="${url}">${title}</a></h2><strong>${price}</strong></div>
      <blockquote>"${story}"</blockquote>
      <button type="button" class="ltv-wish-move" data-wishlist-move="${id}" ${variant}>Move to Cart <iconify-icon icon="lucide:arrow-right"></iconify-icon></button>
      <button type="button" class="ltv-wish-gift" data-gift-add><iconify-icon icon="lucide:gift"></iconify-icon>Add to Gift Builder</button>
    </div>
  </article>`;
}
function initWishlist(){
  const root=document.querySelector("[data-wishlist-page]");
  if(!root)return;
  if(!root.dataset.wishlistDynamic){
    const items=store.get("wishlist");
    root.innerHTML=items.length?`<div class="ltv-page-title"><div><h1>Your Saved Stories</h1><p>These handcrafted pieces carry the voices of their makers. Curate your collection, build a meaningful gift, or bring these stories into your home.</p></div><button class="ltv-btn ltv-btn--terra">Move All to Cart</button></div><div class="ltv-product-grid">${items.map(x=>productCard({...x,artisan:"Saved artisan",city:"India",bundle:true})).join("")}</div>`:`<div class="ltv-center ltv-section"><span class="ltv-eyebrow">Curated for You</span><h1>Your Saved Stories</h1><p>Save the pieces that speak to you. Build a collection of handcrafted treasures and discover the artisans behind them.</p><a class="ltv-btn ltv-btn--terra" href="/collections/all">Explore Collection <iconify-icon icon="lucide:arrow-right"></iconify-icon></a></div><div class="ltv-product-grid">${LTV.products.slice(0,6).map(productCard).join("")}</div>`;
    return;
  }
  const grid=root.querySelector("[data-wishlist-items-grid]");
  const empty=root.querySelector("[data-wishlist-empty]");
  const countEls=document.querySelectorAll("[data-wishlist-item-count]");
  const selectedLabel=document.querySelector("[data-wishlist-selected-label]");
  const getItems=()=>store.get("wishlist");
  function updateSelected(){
    const selected=root.querySelectorAll("[data-wishlist-select]:checked").length;
    if(selectedLabel)selectedLabel.textContent=`${selected} Items Selected`;
  }
  function render(){
    const items=getItems();
    if(grid)grid.innerHTML=items.map(wishlistCard).join("");
    if(empty)empty.hidden=items.length>0;
    const itemLabel=root.dataset.itemsLabel||'items';
    countEls.forEach(el=>{el.textContent=`${items.length} ${items.length===1?'item':itemLabel}`});
    updateSelected();
    store.refreshWishlist();
  }
  root.addEventListener("change",e=>{
    if(e.target.matches("[data-wishlist-select-all]")){
      root.querySelectorAll("[data-wishlist-select]").forEach(input=>{input.checked=e.target.checked});
      updateSelected();
    }
    if(e.target.matches("[data-wishlist-select]"))updateSelected();
  });
  root.addEventListener("click",async e=>{
    const remove=e.target.closest("[data-wishlist-remove]");
    if(remove){
      store.remove("wishlist",remove.dataset.wishlistRemove);
      render();
      return;
    }
    const move=e.target.closest("[data-wishlist-move]");
    if(move){
      const item=getItems().find(x=>x.id===move.dataset.wishlistMove);
      if(item?.variantId)await addToCartAjax(item.variantId,1);
    }
  });
  document.querySelector("[data-wishlist-share]")?.addEventListener("click",async()=>{
    if(navigator.share){try{await navigator.share({title:document.title,url:location.href})}catch(e){}}
    else{try{await navigator.clipboard.writeText(location.href);alert("Wishlist link copied")}catch(e){}}
  });
  document.querySelector("[data-wishlist-move-all]")?.addEventListener("click",async()=>{
    const selected=[...root.querySelectorAll("[data-wishlist-select]:checked")].map(x=>x.value);
    const items=getItems().filter(x=>!selected.length||selected.includes(x.id));
    for(const item of items){if(item.variantId)await addToCartAjax(item.variantId,1)}
  });
  render();
}
function initGift(){const root=document.querySelector("[data-gift-builder]");if(!root)return;const state={center:LTV.products[0],accents:[LTV.products[2],LTV.products[6]],pack:{title:"Signature Recycled Box",price:15,image:"https://images.unsplash.com/photo-1607083206968-13611e3d76db?w=300"}};function total(){return state.center.price+state.accents.reduce((s,x)=>s+x.price,0)+state.pack.price}function render(){root.querySelector("[data-gift-total]").textContent="₹"+total();root.querySelector("[data-gift-summary]").innerHTML=`<div class="ltv-cart-item" style="grid-template-columns:64px 1fr"><img src="${state.center.image}"><div><small>Centerpiece</small><h4>${state.center.title}</h4><strong>₹${state.center.price}</strong></div></div>${state.accents.map(a=>`<div class="ltv-summary-row"><span>${a.title}</span><strong>₹${a.price}</strong></div>`).join("")}<div class="ltv-summary-row"><span>${state.pack.title}</span><strong>₹${state.pack.price}</strong></div>`}render();root.querySelectorAll(".ltv-step__head").forEach(h=>h.addEventListener("click",()=>h.parentElement.classList.toggle("is-open")));root.querySelector("[data-gift-add-cart]").addEventListener("click",()=>{store.add("gift",{id:"custom-gift",title:"Custom LocalTeVocal Gift Set",price:total(),image:state.center.image});alert("Gift set saved")})}
function initSearch(){
  const root=document.querySelector("[data-search-results]");
  if(!root) return;
  const q=new URLSearchParams(location.search).get("q")||"Blue Pottery";
  const queryInput=root.querySelector("[data-search-query]");
  if(queryInput) queryInput.value=q;
  const labelEl=root.querySelector("[data-search-label]");
  if(labelEl) labelEl.textContent=q;
  const resultsEl=root.querySelector("[data-results]");
  if(resultsEl&&!resultsEl.innerHTML.trim()){
    const matches=LTV.products.filter(p=>(p.title+p.craft+p.city).toLowerCase().includes(q.toLowerCase())||q==="Blue Pottery");
    resultsEl.innerHTML=(matches.length?matches:LTV.products.slice(0,6)).map(productCard).join("");
  }
  const filters=root.querySelector("[data-search-filters]");
  const toggle=root.querySelector("[data-search-filter-toggle]");
  const close=root.querySelector("[data-search-filter-close]");
  toggle?.addEventListener("click",()=>{
    const next=!filters?.classList.contains("is-open");
    filters?.classList.toggle("is-open",next);
    toggle.setAttribute("aria-expanded",String(next));
  });
  close?.addEventListener("click",()=>{
    filters?.classList.remove("is-open");
    toggle?.setAttribute("aria-expanded","false");
  });
  root.querySelector(".ltv-search-mobile-controls select")?.addEventListener("change",e=>{
    const form=root.querySelector(".ltv-search-toolbar form");
    const select=form?.querySelector('select[name="sort_by"]');
    if(select&&form){
      select.value=e.target.value;
      form.submit();
    }
  });
  root.querySelector(".ltv-search-bundle-filter input")?.addEventListener("change",()=>{
    root.querySelector(".ltv-search-toolbar form")?.submit();
  });
}
document.addEventListener("DOMContentLoaded",()=>{bindCommon();initGrids();initProduct();initStoriesPage();initCart();initWishlist();initGift();initSearch()});

